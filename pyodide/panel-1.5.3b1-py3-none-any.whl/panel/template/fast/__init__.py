"""
The Fast Templates provide easy to use, great looking templates for
Panel based on the https://fast.design framework.
"""

from .grid import FastGridTemplate  # noqa
from .list import FastListTemplate  # noqa
