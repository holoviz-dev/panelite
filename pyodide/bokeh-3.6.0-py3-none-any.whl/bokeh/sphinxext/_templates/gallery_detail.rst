:orphan:

.. index::
   single: examples; {{ filename }}

{{ ref }}

{{ filename }}
{{ '-' * filename|length }}

.. bokeh-plot:: {{ source_path }}
    :process-docstring:
    :source-position: below
