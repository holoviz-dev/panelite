import {div, px} from "@bokehjs/core/dom"
import type {DOMView} from "@bokehjs/core/dom_view"
import {isArray} from "@bokehjs/core/util/types"
import {unreachable} from "@bokehjs/core/util/assert"
import {WidgetView} from "@bokehjs/models/widgets/widget"
import type {Markup} from "@bokehjs/models/widgets/markup"
import {LayoutDOM, LayoutDOMView} from "@bokehjs/models/layouts/layout_dom"
import type {UIElement} from "@bokehjs/models/ui/ui_element"
import type * as p from "@bokehjs/core/properties"

import type {ExternalResourcesModel, ResourceSpec} from "./resources"
import {
  await_resources, define_external_resources, load_resources,
  render_resource_error,
} from "./resources"

/**
 * Re-renders a view, including its layout.
 *
 * Bokeh's own `rerender` runs the whole render walk before `update_layout`,
 * which is wrong for anything that is positioned by the layout: `render`
 * re-parents annotation elements into the canvas layers and it is
 * `update_layout` that moves them into their side panels. Measuring in
 * between therefore caches a bbox for the container the element is about to
 * leave, e.g. a legend measuring the full canvas width instead of its side
 * panel. `compute_layout` then sizes the panel from that stale bbox and can
 * squeeze the frame to zero, which poisons everything derived from it (for
 * tile-based plots, a division by zero width puts NaN into the ranges with no
 * recovery path). Updating the layout first means `after_render` measures
 * elements where they will actually live.
 *
 * `layout=false` skips `compute_layout`, for callers that render several
 * children in a row and lay out once afterwards: a child's `compute_layout`
 * lays out its whole root, so rendering N children would cost N full passes.
 */
export function rerender_view(view: DOMView, layout: boolean = true): void {
  if (view instanceof LayoutDOMView) {
    view.render()
    view.update_layout()
    view.r_after_render()
    if (layout) {
      view.compute_layout()
    }
  } else if (view.rerender) {
    // Can be removed when Bokeh>3.7 (see https://github.com/holoviz/panel/pull/7815)
    view.rerender()
  } else {
    view.render()
    view.r_after_render()
  }
}

/**
 * Tracks the `<link>` stylesheets of a view and calls `settled` once all of
 * them have loaded *or* failed, or immediately if none are pending. Views
 * reveal their content from that callback, so a stylesheet that never arrives
 * must not hide them forever, while revealing earlier lays them out unstyled.
 */
function watch_link_stylesheets(
  stylesheets: Iterable<unknown>, signal: AbortSignal, settled: () => void,
): Map<string, boolean> {
  const state = new Map<string, boolean>()
  const all_settled = () => [...state.values()].every((v) => v)
  for (const stylesheet of stylesheets) {
    const style_el = (stylesheet as any).el
    if (style_el instanceof HTMLLinkElement) {
      // A link served from cache may already have loaded, and `load` does
      // not fire again for it.
      state.set(style_el.href, style_el.sheet != null)
      const on_settled = () => {
        state.set(style_el.href, true)
        if (all_settled()) {
          settled()
        }
      }
      style_el.addEventListener("load", on_settled, {signal})
      style_el.addEventListener("error", on_settled, {signal})
    }
  }
  if (all_settled()) {
    settled()
  }
  return state
}

export class PanelMarkupView extends WidgetView {
  declare model: Markup

  container: HTMLDivElement
  protected _initialized_stylesheets: Map<string, boolean>
  protected _stylesheets_watcher: AbortController | null = null

  override connect_signals(): void {
    super.connect_signals()
    const {width, height, min_height, max_height, margin, sizing_mode} = this.model.properties
    this.on_change([width, height, min_height, max_height, margin, sizing_mode], () => {
      set_size(this.el, this.model)
      set_size(this.container, this.model, false)
    })
  }

  override async lazy_initialize() {
    await super.lazy_initialize()

    const error = await await_resources(this.model as unknown as ExternalResourcesModel)
    if (error != null) {
      render_resource_error(this, error, PanelMarkupView.prototype.render)
    }

    if (this.provider.status == "not_started" || this.provider.status == "loading") {
      this.provider.ready.connect(() => {
        if (this.contains_tex_string(this.model.text)) {
          this.render()
        }
      })
    }
  }

  /**
   * Schedules `style_redraw` for when all applied stylesheets have settled.
   * Listeners registered by a previous call are cancelled, since the
   * elements they watch have been discarded.
   */
  watch_stylesheets(): void {
    this._stylesheets_watcher?.abort()
    const {signal} = this._stylesheets_watcher = new AbortController()
    let watching = false
    this._initialized_stylesheets = watch_link_stylesheets(this._applied_stylesheets, signal, () => {
      if (watching) {
        requestAnimationFrame(() => this.style_redraw())
      } else {
        this.style_redraw()
      }
    })
    watching = true
  }

  /**
   * Bokeh recreates the stylesheet elements on every update, discarding the
   * ones `watch_stylesheets` listens on, so the watcher has to be re-armed.
   * Skipped until the view has armed it itself, as the update triggered from
   * `super.render()` precedes the creation of `this.container`.
   */
  protected override _update_stylesheets(): void {
    super._update_stylesheets()
    if (this._stylesheets_watcher != null) {
      this.watch_stylesheets()
    }
  }

  rerender_(view: DOMView | null = null): void {
    rerender_view(view == null ? this : view)
  }

  style_redraw(): void {}

  has_math_disabled(): boolean {
    return this.model.disable_math || !this.contains_tex_string(this.model.text)
  }

  override render(): void {
    super.render()
    set_size(this.el, this.model)
    this.container = div()
    set_size(this.container, this.model, false)
    this.shadow_el.appendChild(this.container)

    if (this.provider.status == "failed" || this.provider.status == "loaded") {
      this._has_finished = true
    }
  }
}

export function set_size(el: HTMLElement, model: LayoutDOM, adjust_margin: boolean = true): void {
  let width_policy = model.width != null ? "fixed" : "fit"
  let height_policy = model.height != null ? "fixed" : "fit"
  const {sizing_mode, margin} = model
  if (sizing_mode != null) {
    if (sizing_mode == "fixed") {
      width_policy = height_policy = "fixed"
    } else if (sizing_mode == "stretch_both") {
      width_policy = height_policy = "max"
    } else if (sizing_mode == "stretch_width") {
      width_policy = "max"
    } else if (sizing_mode == "stretch_height") {
      height_policy = "max"
    } else {
      switch (sizing_mode) {
        case "scale_width": {
          width_policy = "max"
          height_policy = "min"
          break
        }
        case "scale_height": {
          width_policy = "min"
          height_policy = "max"
          break
        }
        case "scale_both": {
          width_policy = "max"
          height_policy = "max"
          break
        }
        case "inherit": {
          break
        }
        default: {
          unreachable()
        }
      }
    }
  }
  let wm: number, hm: number
  if (!adjust_margin) {
    hm = wm = 0
  } else if (isArray(margin)) {
    if (margin.length === 4) {
      hm = margin[0] + margin[2]
      wm = margin[1] + margin[3]
    } else {
      hm = margin[0]*2
      wm = margin[1]*2
    }
  } else if (margin == null) {
    hm = wm = 0
  } else {
    wm = hm = margin*2
  }

  if (width_policy == "fixed" && model.width != null) {
    el.style.width = px(model.width)
  } else if (width_policy == "max") {
    el.style.width = wm != 0 ? `calc(100% - ${px(wm)})` : "100%"
  }
  if (model.min_width != null) {
    el.style.minWidth = px(model.min_width)
  }
  if (model.max_width != null) {
    el.style.maxWidth = px(model.max_width)
  }

  if (height_policy == "fixed" && model.height != null) {
    el.style.height = px(model.height)
  } else if (height_policy == "max") {
    el.style.height = hm != 0 ? `calc(100% - ${px(hm)})` : "100%"
  }
  if (model.min_height != null) {
    el.style.minHeight = px(model.min_height)
  }
  if (model.max_height != null) {
    el.style.maxHeight = px(model.max_height)
  }
}

export abstract class HTMLBoxView extends LayoutDOMView {
  declare model: HTMLBox

  protected _initialized_stylesheets: Map<string, boolean> = new Map()
  protected _stylesheets_watcher: AbortController | null = null

  override connect_signals(): void {
    super.connect_signals()
    const {width, height, min_height, max_height, margin, sizing_mode} = this.model.properties
    this.on_change([width, height, min_height, max_height, margin, sizing_mode], () => {
      set_size(this.el, this.model)
    })
  }

  override async lazy_initialize(): Promise<void> {
    await super.lazy_initialize()
    const error = await await_resources(this.model)
    if (error != null) {
      render_resource_error(this, error, HTMLBoxView.prototype.render)
    }
  }

  override render(): void {
    super.render()
    set_size(this.el, this.model)
  }

  rerender_(view: DOMView | null = null): void {
    rerender_view(view == null ? this : view)
  }

  /**
   * Schedules `style_redraw` for when all applied stylesheets have settled.
   * Always deferred by a frame because subclasses arm the watcher before
   * creating the content `style_redraw` operates on.
   */
  watch_stylesheets(): void {
    this._stylesheets_watcher?.abort()
    const {signal} = this._stylesheets_watcher = new AbortController()
    this._initialized_stylesheets = watch_link_stylesheets(this._applied_stylesheets, signal, () => {
      requestAnimationFrame(() => this.style_redraw())
    })
  }

  get stylesheets_settled(): boolean {
    return [...this._initialized_stylesheets.values()].every((v) => v)
  }

  /** Bokeh recreates the stylesheet elements on update, so re-arm the watcher. */
  protected override _update_stylesheets(): void {
    super._update_stylesheets()
    if (this._stylesheets_watcher != null) {
      this.watch_stylesheets()
    }
  }

  override remove(): void {
    this._stylesheets_watcher?.abort()
    this._stylesheets_watcher = null
    super.remove()
  }

  style_redraw(): void {}

  get child_models(): UIElement[] {
    return []
  }
}

export namespace HTMLBox {
  export type Attrs = p.AttrsOf<Props>
  export type Props = LayoutDOM.Props & {
    external_resources: p.Property<ResourceSpec | null>
  }
}

export interface HTMLBox extends HTMLBox.Attrs {}

export abstract class HTMLBox extends LayoutDOM {
  declare properties: HTMLBox.Props

  constructor(attrs?: Partial<HTMLBox.Attrs>) {
    super(attrs)
  }

  static {
    define_external_resources(this)
  }

  /**
   * Starts loading the component's external libraries.
   *
   * Every model in a document is initialized before the first view is built
   * and `build_views` then builds them one at a time, so kicking the fetch
   * off here is what keeps a page of ten components waiting for the slowest
   * library rather than for all of them in sequence.
   */
  override initialize(): void {
    super.initialize()
    load_resources(this)
  }
}
