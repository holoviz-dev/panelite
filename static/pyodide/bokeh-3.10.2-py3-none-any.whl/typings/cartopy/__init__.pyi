# Cartopy package stub.
