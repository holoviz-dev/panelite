"""
Patches bokeh resources to make it easy to add external JS and CSS
resources via the panel.config object.
"""
from __future__ import annotations

import functools
import importlib
import json
import logging
import mimetypes
import os
import pathlib
import re
import textwrap
import typing as t
import uuid

from contextlib import contextmanager
from contextvars import ContextVar
from functools import lru_cache
from pathlib import Path

import bokeh.embed.wrappers

from bokeh.core.property.descriptors import UnsetValueError
from bokeh.embed.bundle import (
    CSS_RESOURCES as BkCSS_RESOURCES, URL, Bundle as BkBundle,
    _bundle_extensions, _query_extensions, _use_mathjax, _use_tables,
    bundle_models, extension_dirs,
)
from bokeh.embed.util import contains_tex_string
from bokeh.model import Model
from bokeh.models import ImportedStyleSheet, InlineStyleSheet
from bokeh.resources import Resources as BkResources, _get_server_urls
from bokeh.settings import _Unset, settings as _settings
from jinja2.environment import Environment
from jinja2.loaders import FileSystemLoader
from markupsafe import Markup

from ..config import config, panel_extension as extension
from ..util import _descendents, isurl, url_path
from .pages import page_theme
from .state import state

if t.TYPE_CHECKING:
    from bokeh.core.has_props import HasProps
    from bokeh.document import Document
    from bokeh.resources import Urls

    class TarballType(t.TypedDict, total=False):
        tar: str
        src: str
        dest: str
        exclude: list[str]

    class ResourcesType(t.TypedDict, total=False):
        css: dict[str, str]
        font: dict[str, str]
        js: dict[str, str]
        js_modules: dict[str, str]
        raw_css: list[str]
        tarball: dict[str, TarballType]
        bundle: bool

    MODES = t.Literal['inline', 'cdn', 'server', 'relative', 'absolute', 'server-dev', 'relative-dev', 'absolute-dev']

logger = logging.getLogger(__name__)

ResourceAttr = t.Literal["__css__", "__javascript__"]

with open(Path(__file__).parent.parent / 'package.json') as f:
    package_json = json.load(f)
    JS_VERSION = package_json['version'].split('+')[0]

def get_env():
    ''' Get the correct Jinja2 Environment, also for frozen scripts.
    '''
    internal_path = Path(__file__).parent / '..' / '_templates'
    template_path = Path(__file__).parent / '..' / 'template'
    return Environment(loader=FileSystemLoader([
        str(internal_path.resolve()), str(template_path.resolve())
    ]))

def conffilter(value):
    return json.dumps(dict(value)).replace('"', '\'')

class json_dumps(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, URL):
            return str(obj)
        return super().default(obj)

_env = get_env()
_env.trim_blocks = True
_env.lstrip_blocks = True
_env.filters['json'] = lambda obj: Markup(json.dumps(obj, cls=json_dumps))
_env.filters['conffilter'] = conffilter
_env.filters['sorted'] = sorted
# A global so that user supplied auth, logout and error templates can use the
# page theme without every handler passing it.
_env.globals['page'] = page_theme

@functools.cache
def parse_template(*args, **kwargs):
    return _env.from_string(*args, **kwargs)

# Handle serving of the panel extension before session is loaded
RESOURCE_MODE: MODES = 'server'
NOTEBOOK_RESOURCES = False
# Kernels inherit the environment of the Jupyter server that launched them,
# which is the only reliable sign the server registered Panel's endpoint.
JUPYTER_ENDPOINT_ENV = 'PANEL_JUPYTER_ENDPOINT'
PANEL_DIR = Path(__file__).parent.parent
DIST_DIR = PANEL_DIR / 'dist'
BUNDLE_DIR = DIST_DIR / 'bundled'
ASSETS_DIR = PANEL_DIR / 'assets'
INDEX_TEMPLATE = _env.get_template('convert_index.html')
BASE_TEMPLATE = _env.get_template('base.html')
ERROR_TEMPLATE = _env.get_template('error.html')
LOGOUT_TEMPLATE = _env.get_template('logout.html')
BASIC_LOGIN_TEMPLATE = _env.get_template('basic_login.html')
DEFAULT_TITLE = "Panel Application"
JS_RESOURCES = _env.get_template('js_resources.html')
CDN_ROOT = config.cdn_root
CDN_URL = f"{CDN_ROOT}{JS_VERSION}/"
CDN_DIST = f"{CDN_URL}dist/"
DOC_DIST = "https://panel.holoviz.org/_static/"
LOCAL_DIST = "static/extensions/panel/"
COMPONENT_PATH = "components/"

BK_PREFIX_RE = re.compile(r'\.bk\.')

# Maps between extension dist directories and CDN
EXTENSION_CDN: dict[str | Path, str] = {}

RESOURCE_URLS = {
    'font-awesome': {
        'zip': 'https://use.fontawesome.com/releases/v5.15.4/fontawesome-free-5.15.4-web.zip',
        'src': 'fontawesome-free-5.15.4-web/',
        'exclude': ['*.svg', '*.scss', '*.less']
    },
    'bootstrap4': {
        'tar': 'https://registry.npmjs.org/bootstrap/-/bootstrap-4.6.1.tgz',
        'src': 'package/dist',
        'exclude': [],
        'dest': ''
    },
    'bootstrap5': {
        'tar': 'https://registry.npmjs.org/bootstrap/-/bootstrap-5.3.0-alpha1.tgz',
        'src': 'package/dist',
        'exclude': [],
        'dest': ''
    },
    'jQuery': {
        'tar': 'https://registry.npmjs.org/jquery/-/jquery-3.5.1.tgz',
        'src': 'package/dist',
        'exclude': [],
        'dest': ''
    }
}

CSS_URLS = {
    'font-awesome': f'{CDN_DIST}bundled/font-awesome/css/all.min.css',
    'bootstrap4': f'{CDN_DIST}bundled/bootstrap4/css/bootstrap.min.css',
    'bootstrap5': f'{CDN_DIST}bundled/bootstrap5/css/bootstrap.min.css'
}

JS_URLS = {
    'jQuery': f'{CDN_DIST}bundled/jquery/jquery.min.js',
    'bootstrap4': f'{CDN_DIST}bundled/bootstrap4/js/bootstrap.bundle.min.js',
    'bootstrap5': f'{CDN_DIST}bundled/bootstrap5/js/bootstrap.bundle.min.js'
}

extension_dirs['panel'] = DIST_DIR

bokeh.embed.wrappers._ONLOAD = """\
(function() {
  const fn = function() {
%(code)s
  };
  if (document.readyState != "loading") fn();
else document.addEventListener("DOMContentLoaded", fn, {once: true});
})();\
"""

mimetypes.add_type("application/javascript", ".js")

@contextmanager
def set_resource_mode(mode: MODES | None):
    global RESOURCE_MODE
    if mode is None:
        mode = RESOURCE_MODE
    old_resources = _settings.resources._user_value
    old_mode = RESOURCE_MODE
    _settings.resources = RESOURCE_MODE = mode
    try:
        yield
    finally:
        RESOURCE_MODE = old_mode
        if old_resources is _Unset:
            _settings.resources.unset_value()
        else:
            _settings.resources.set_value(old_resources)  # type: ignore

def get_resource_mode() -> MODES:
    """
    The mode urls are currently being resolved for.

    Has to be read through a function: ``set_resource_mode`` rebinds the
    module global, so a module that imported the name would keep whatever
    it happened to be at import time.
    """
    return RESOURCE_MODE

def get_notebook_resources() -> bool:
    """Whether resource urls should use the Jupyter extension endpoint."""
    return NOTEBOOK_RESOURCES

def jupyter_endpoint_available() -> bool:
    """
    Whether notebook output loads resources from Panel's Jupyter server
    extension, as selected by `config.notebook_resources`.

    By default that is the case if this process was launched by a Jupyter
    server that serves the extension.
    """
    mode = config.notebook_resources
    if mode == 'cdn':
        return False
    return mode == 'jupyter' or bool(os.environ.get(JUPYTER_ENDPOINT_ENV))

def jupyter_endpoint_root() -> str:
    """
    The root url of the Jupyter server extension, e.g. ``/panel-preview/``.
    """
    # The render endpoint sets `rel_path` to its own `panel-preview` root
    # already, so building on `base_url` there would double it. nbclassic
    # never sets `rel_path`, so `base_url` is the raw server root there.
    if state.rel_path and state.rel_path.rstrip('/').endswith('panel-preview'):
        return f"{state.rel_path.rstrip('/')}/"
    base_url = state.base_url.removesuffix('nbclassic/')
    return f'{base_url}panel-preview/'

def notebook_extension_url(path: str) -> str | None:
    """
    Resolves a ``static/extensions/<name>/...`` path against the Jupyter
    server extension when notebook output is served by it.

    Returns None if the endpoint is not in use, e.g. in a server session,
    with inlined resources or when the endpoint is not available.
    """
    if (
        config.inline or state._is_pyodide or state._is_server_session
        or not (NOTEBOOK_RESOURCES and jupyter_endpoint_available())
        or not path.startswith('static/extensions/')
    ):
        return None
    return f'{jupyter_endpoint_root()}{path}'

def set_default_resource_mode(mode: MODES, *, notebook: bool = False):
    """
    Sets the mode urls are resolved for outside a set_resource_mode block.

    The module default is ``server``, i.e. relative urls into the static
    endpoint Panel itself serves, which is the right guess for an
    application but wrong for a notebook: the page is served by Jupyter
    from an unrelated url, so ``static/extensions/panel/...`` resolves
    against ``/lab/tree/<dir>/`` and 404s. It cannot be handled by a
    context manager either, because components created in a later cell
    resolve their resources long after ``pn.extension()`` returned.
    """
    global NOTEBOOK_RESOURCES, RESOURCE_MODE
    RESOURCE_MODE = mode
    NOTEBOOK_RESOURCES = notebook

def use_cdn() -> bool:
    return _settings.resources(default="server") != 'server' or state._is_pyodide

def extension_cdn_map() -> list[tuple[str, str]]:
    """
    Pairs of server extension paths (``static/extensions/<name>/``) and
    the CDN urls serving the same files, for Panel and every extension
    with a CDN.
    """
    cdn_map = [(LOCAL_DIST, CDN_DIST)]
    extension_cdns = {Path(path).resolve(): cdn for path, cdn in EXTENSION_CDN.items()}
    for name, dist in extension_dirs.items():
        cdn = extension_cdns.get(Path(dist).resolve())
        if name != 'panel' and cdn:
            cdn_map.append((f'static/extensions/{name}/', f"{cdn.rstrip('/')}/"))
    return cdn_map

def get_dist_path(cdn: bool | t.Literal['auto'] = 'auto') -> str:
    cdn = use_cdn() if cdn == 'auto' else cdn
    if cdn:
        dist_path = CDN_DIST
    elif state.rel_path:
        dist_path = f'{state.rel_path}/{LOCAL_DIST}'
    else:
        dist_path = f'{LOCAL_DIST}'
    return dist_path

def is_cdn_url(url: str) -> bool:
    return isurl(url) and url.startswith(CDN_DIST)

def process_raw_css(raw_css: list[str]) -> list[str]:
    """
    Converts old-style Bokeh<3 compatible CSS to Bokeh 3 compatible CSS.
    """
    return [BK_PREFIX_RE.sub('.', css) for css in raw_css]

@lru_cache(maxsize=None)
def loading_css(loading_spinner: str, color: str, max_height: int):
    size = f"calc(min(40px, {max_height}px))"
    return textwrap.dedent(f"""
    :host(.pn-loading):before, .pn-loading:before {{
      background-color: {color};
      width: {size};
      height: {size};
      mask-size: {size} {size};
      -webkit-mask-size: {size} {size};
    }}""")

def resolve_custom_path(
    obj, path: str | os.PathLike, relative: bool = False
) -> Path | None:
    """
    Attempts to resolve a path relative to some component.

    Parameters
    ----------
    obj: type | object
       The component to resolve the path relative to.
    path: str | os.PathLike
        Absolute or relative path to a resource.
    relative: bool
        Whether to return a relative path.

    Returns
    -------
    path: pathlib.Path | None
    """
    if not path:
        return None
    if not isinstance(obj, type):
        obj = type(obj)
    try:
        mod = importlib.import_module(obj.__module__)
        if mod.__file__ is None:
            return None
        module_path = Path(mod.__file__).parent
        assert module_path.exists()
    except Exception:
        return None
    path = Path(path)
    if path.is_absolute():
        abs_path = path
    else:
        abs_path = module_path / path
    try:
        if not abs_path.is_file():
            return None
    except OSError:
        return None
    abs_path = Path(os.path.normpath(abs_path.absolute()))
    if not relative:
        return abs_path
    return Path(os.path.relpath(abs_path, module_path))

def component_resource_path(component, attr: str, path: str | os.PathLike) -> str:
    """
    Generates a canonical URL for a component resource.

    To be used in conjunction with the `panel.io.server.ComponentResourceHandler`
    which allows dynamically resolving resources defined on components.
    """
    if not isinstance(component, type):
        component = type(component)
    component_path = COMPONENT_PATH

    # Attempt to see if custom resource path is actually
    # a subpath of an existing bokeh extension
    is_ext = False
    for ext, dist_dir in extension_dirs.items():
        if _is_subpath(path, dist_dir):
            is_ext = True
            component_path = f'static/extensions/{ext}'
            break

    if state.rel_path:
        component_path = f"{state.rel_path}/{component_path}"

    # If the component path was matched against a registered extension
    # we can resolve it relative to that path instead of using the custom
    # resource handler
    if is_ext:
        dist_path = str(path).replace(str(dist_dir.absolute()), '').replace(os.path.sep, '/')
        return f'{component_path}{dist_path}'
    custom_path = resolve_custom_path(component, path, relative=True)
    rel_path = os.fspath(custom_path).replace(os.path.sep, '/') if custom_path else path
    return f'{component_path}{component.__module__}/{component.__name__}/{attr}/{rel_path}'

def stylesheet_url(stylesheet: ImportedStyleSheet) -> str | None:
    """
    Returns the url of an ImportedStyleSheet or None if it is unset.

    Bokeh clears the property values of every model on a Document when
    the Document is destroyed at the end of a session. An
    ImportedStyleSheet that outlives the Document it was rendered into,
    e.g. because it is held in a cache, is therefore left without a url
    and reading it raises an UnsetValueError. Such a stylesheet must
    never be reused since it breaks both model creation and the
    serialization of the Document it is added to.
    """
    try:
        return stylesheet.url
    except UnsetValueError:
        return None

_STYLESHEET_SCOPE: ContextVar[tuple[Document, dict[str, ImportedStyleSheet]] | None] = ContextVar(
    '_STYLESHEET_SCOPE', default=None
)

@contextmanager
def stylesheet_scope(doc: Document | None):
    """
    Makes the ImportedStyleSheets already shared by the models on a
    Document available to imported_stylesheet while the properties of
    a component rendered into that Document are computed.
    """
    if doc is None:
        yield
        return
    cache = state._stylesheets.get(doc)
    if cache is None:
        cache = state._stylesheets[doc] = {}
    token = _STYLESHEET_SCOPE.set((doc, cache))
    try:
        yield
    finally:
        _STYLESHEET_SCOPE.reset(token)

def imported_stylesheet(url: str) -> ImportedStyleSheet:
    """
    Returns an ImportedStyleSheet for the url. Within a stylesheet_scope
    the stylesheet shared on the Document is returned if there is one,
    since every component would otherwise construct its own only for it
    to be replaced by the shared one when the stylesheets are resolved.
    """
    scope = _STYLESHEET_SCOPE.get()
    if scope is not None:
        doc, cache = scope
        cached = cache.get(url)
        if cached is not None and stylesheet_url(cached) is not None and cached.document in (None, doc):
            return cached
    return ImportedStyleSheet(url=url)

def shared_inline_stylesheet(
    css: str, cache: dict[str, InlineStyleSheet], doc: Document
) -> InlineStyleSheet:
    """
    Returns the InlineStyleSheet holding the CSS on a Document, creating
    it on first use so every model on the Document references the same
    instance. A cached stylesheet is replaced if it was destroyed along
    with a previous Document or is still attached to another one.
    """
    cached = cache.get(css)
    if cached is not None:
        try:
            if cached.css == css and cached.document in (None, doc):
                return cached
        except UnsetValueError:
            pass
    cache[css] = stylesheet = InlineStyleSheet(css=css)
    return stylesheet

def patch_stylesheet(stylesheet, dist_url):
    url = stylesheet_url(stylesheet)
    if url is None:
        return
    if url.startswith(CDN_DIST+dist_url) and dist_url != CDN_DIST:
        patched_url = url.replace(CDN_DIST+dist_url, dist_url)
    elif url.startswith(CDN_DIST) and dist_url != CDN_DIST:
        patched_url = url.replace(CDN_DIST, dist_url)
    elif url.startswith(LOCAL_DIST) and dist_url.lstrip('./').startswith(LOCAL_DIST):
        patched_url = url.replace(LOCAL_DIST, dist_url)
    elif url.startswith(LOCAL_DIST) and dist_url != LOCAL_DIST:
        patched_url = url.replace(LOCAL_DIST, dist_url)
    else:
        return
    version_suffix = f'?v={JS_VERSION}'
    if not patched_url.endswith(version_suffix):
        patched_url += version_suffix
    try:
        stylesheet.url = patched_url
    except Exception:
        pass

def _is_file_path(stylesheet: str)->bool:
    return stylesheet.lower().endswith(".css")

def _is_subpath(path: str | os.PathLike, parent: str | os.PathLike) -> bool:
    """
    Return True if `path` is located inside `parent` (or equal to it).
    Both paths are resolved (absolute, symlinks resolved).
    """
    path = Path(os.path.normpath(os.path.abspath(path)))
    parent = Path(os.path.normpath(os.path.abspath(parent)))
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False

def resolve_resource_cdn(resource: str | os.PathLike) -> str | os.PathLike:
    """
    Resolves a CDN URL given a file path that is relative to
    an extension dist directory.
    """
    for p, cdn in EXTENSION_CDN.items():
        if _is_subpath(resource, p):
            resource = str(resource).replace(os.path.abspath(p), cdn).replace(os.path.sep, '/')
            break
    return resource

def resolve_stylesheet(cls, stylesheet: str, attribute: str | None = None):
    """
    Resolves a stylesheet definition, e.g. originating on a component
    Reactive._stylesheets or a Design.modifiers attribute. Stylesheets
    may be defined as one of the following:

    - Absolute URL defined with http(s) protocol
    - A path relative to the component
    - A raw css string

    Parameters
    ----------
    cls: type | object
        Object or class defining the stylesheet
    stylesheet: str
        The stylesheet definition
    """
    stylesheet = os.fspath(stylesheet)
    if stylesheet.startswith('http') or not (attribute and _is_file_path(stylesheet) and (custom_path:= resolve_custom_path(cls, stylesheet))):
        return stylesheet
    if not state._is_pyodide and state.curdoc and state.curdoc.session_context:
        stylesheet = component_resource_path(cls, attribute, stylesheet)
        if config.autoreload and '?' not in stylesheet:
            stylesheet += f'?v={uuid.uuid4().hex}'
    else:
        stylesheet = custom_path.read_text(encoding='utf-8')
    return stylesheet

def patch_model_css(root: Model, dist_url: str):
    """
    Temporary patch for Model.css property used by Panel to provide
    stylesheets for components.

    ALERT: Should find better solution before official Bokeh 3.x compatible release
    """
    # Patch model CSS properties
    doc = root.document
    stylesheets: t.Iterable[Model]
    if doc:
        held = doc.callbacks.hold_value
        events = list(doc.callbacks._held_events)
        doc.hold()
        stylesheets = [m for m in _document_models(doc) if isinstance(m, ImportedStyleSheet)]
    else:
        stylesheets = root.select({'type': ImportedStyleSheet})
    for stylesheet in stylesheets:
        patch_stylesheet(stylesheet, dist_url)
    if doc:
        doc.callbacks._held_events = events
        if held or not state._loaded.get(doc):
            doc.callbacks._hold = held
        else:
            doc.unhold()

def global_css(name: str) -> str:
    if RESOURCE_MODE == 'server':
        return f'static/extensions/panel/css/{name}.css'
    else:
        return f'{CDN_DIST}css/{name}.css'

_BUNDLED_FILES: dict[tuple, list[str]] = {}

def bundled_files(model: Model, file_type: str = 'javascript') -> list[str]:
    raw_files = getattr(model, f"__{file_type}_raw__", [])
    if config.autoreload:
        return _bundled_files(model, file_type, raw_files)
    key = (model, file_type, RESOURCE_MODE, config.npm_cdn, tuple(raw_files))
    if key in _BUNDLED_FILES:
        return list(_BUNDLED_FILES[key])
    return list(remember(_BUNDLED_FILES, key, _bundled_files(model, file_type, raw_files), limit=256))

def _bundled_files(model: Model, file_type: str, raw_files: list[str]) -> list[str]:
    name = model.__name__.lower()
    for cls in model.__mro__[1:]:
        cls_files = getattr(cls, f"__{file_type}_raw__", [])
        if raw_files is cls_files:
            name = cls.__name__.lower()
    bdir = BUNDLE_DIR / name
    shared = list((JS_URLS if file_type == 'javascript' else CSS_URLS).values())
    files = []
    npm_cdn_prefixes = (config.npm_cdn, 'https://cdn.jsdelivr.net/npm', 'https://unpkg.com')
    for url in raw_files:
        if url.startswith(CDN_DIST):
            filepath = url.replace(f'{CDN_DIST}bundled/', '')
        elif url.startswith(npm_cdn_prefixes):
            for prefix in npm_cdn_prefixes:
                if url.startswith(prefix):
                    filepath = url.replace(prefix, '')[1:]
                    break
        else:
            filepath = url_path(url)
        test_filepath = filepath.split('?')[0]
        if url in shared:
            prefixed = filepath
            test_path = BUNDLE_DIR / test_filepath
        elif not test_filepath.replace('/', '').startswith(f'{name}/'):
            prefixed = f'{name}/{test_filepath}'
            test_path = bdir / test_filepath
        else:
            prefixed = test_filepath
            test_path = BUNDLE_DIR / test_filepath
        if test_path.is_file():
            if RESOURCE_MODE == 'server':
                files.append(f'static/extensions/panel/bundled/{prefixed}')
            elif filepath == test_filepath:
                files.append(f'{CDN_DIST}bundled/{prefixed}')
            else:
                files.append(url)
        else:
            files.append(url)
    return files

def model_registry_key() -> tuple[type, ...]:
    """
    Identifies the current contents of Bokeh's model registry.

    Caches derived from the registry key on this rather than on its size,
    since tests (and ``Model.clear_extensions``) unregister and re-register
    classes, which leaves the size unchanged.
    """
    return tuple(Model.model_class_reverse_map.values())


def remember(cache: dict, key: t.Hashable, value: t.Any, limit: int = 32) -> t.Any:
    """
    Stores a value in a bounded cache, evicting the oldest entry first.
    """
    if len(cache) >= limit:
        cache.pop(next(iter(cache)))
    cache[key] = value
    return value


_SORTED_MODELS: tuple[tuple[type, ...], list[type]] | None = None

def sorted_model_classes() -> list[type]:
    """
    The registered model classes sorted by qualified name.
    """
    global _SORTED_MODELS
    registry = Model.model_class_reverse_map
    key = tuple(registry.values())
    if _SORTED_MODELS is None or _SORTED_MODELS[0] != key:
        _SORTED_MODELS = (key, [cls for _, cls in sorted(registry.items(), key=lambda item: item[0])])
    return _SORTED_MODELS[1]


def loaded_custom_classes() -> list[type]:
    """The ReactiveHTML/ReactiveESM classes whose extension is loaded."""
    from ..reactive import ReactiveCustomBase
    return [
        cls for cls in _descendents(ReactiveCustomBase, concrete=True) if cls._loaded()
    ]


_EXTENSION_MODULES: tuple[tuple[int, int], dict[str, str]] = ((0, 0), {})

def _extension_modules() -> dict[str, str]:
    """Maps the module of an extension's models to the extension name."""
    global _EXTENSION_MODULES
    imports = extension._imports
    key = (id(imports), len(imports))
    if _EXTENSION_MODULES[0] != key:
        _EXTENSION_MODULES = (key, {module: name for name, module in imports.items()})
    return _EXTENSION_MODULES[1]


def extension_declared(cls: type) -> bool:
    """
    Whether a model class' extension was declared in this session.

    Classes that do not belong to an extension always pass, as does every
    class when there is no session to ask (a notebook, or rendering
    outside a document), which is what keeps those paths eager.
    """
    extensions = state._extensions
    if extensions is None:
        return True
    ext = _extension_modules().get(cls.__module__)
    return ext is None or ext in extensions


def module_tags(
    js_modules: list[str], js_module_exports: dict[str, str]
) -> list[tuple[str, str | None]]:
    """
    Pairs each module url with the global its namespace is exported as.

    A module that has an export wrapper is loaded by that wrapper's ``import``,
    so emitting a bare ``<script type="module" src>`` for it as well leaves two
    tags for one url. Pairing them keeps every module in the order
    ``js_modules`` gives, which is the order they execute in.
    """
    exports = {url: name for name, url in js_module_exports.items()}
    tags: list[tuple[str, str | None]] = [
        (url, exports.pop(url, None)) for url in js_modules
    ]
    return tags + list(exports.items())


def _referenced_models(roots) -> set[HasProps]:
    models: set[HasProps] = set()
    for root in roots:
        models |= root.references()
    return models


def _document_models(doc) -> set[HasProps]:
    """
    All models of a Document, from its model index when that is current.

    The index is only recomputed once a ``freeze`` block exits, so while
    frozen the roots have to be walked.
    """
    manager = doc.models
    if getattr(manager, '_freeze_count', 0):
        models: set[HasProps] = set()
        for root in doc.roots:
            models |= root.references()
        return models
    return set(manager)


def _reachable_models(roots) -> set[HasProps]:
    """
    All models reachable from roots, read off the Document's model index
    instead of walking the references when the roots are attached to one.
    """
    doc = None
    for root in roots:
        if root.document is None or (doc is not None and root.document is not doc):
            break
        doc = root.document
    else:
        if doc is not None:
            return _document_models(doc)
    models: set[HasProps] = set()
    for root in roots:
        models |= root.references()
    return models


def _panel_use_mathjax(models: set[HasProps]) -> bool:
    """
    Whether any Panel markup model needs MathJax, i.e. a MathJax pane is
    present or an HTML model has math enabled and its text contains a
    pair of MathJax delimiters.
    """
    from ..models.markup import HTML as PanelHTML
    for obj in models:
        if type(obj).__module__ == 'panel.models.mathjax':
            return True
        if (
            isinstance(obj, PanelHTML) and not obj.disable_math
            and contains_tex_string(obj.text)
        ):
            return True
    return False


def _panel_use_tables(models: set[HasProps]) -> bool:
    """
    Whether any model requires the bokeh-tables bundle.

    Tabulator renders without it, but Bokeh's DataTable and DataCube need it
    and so do extensions defining custom cell editors or formatters.
    """
    from bokeh.models.widgets.tables import CellEditor, CellFormatter
    return _use_tables(models) or _query_extensions(
        models, lambda cls: issubclass(cls, (CellEditor, CellFormatter))
    )


_EXTENSION_BUNDLES: dict[tuple, list] = {}

def _extension_bundles(resources: BkResources) -> list:
    """
    The bundles of every registered extension, cached per resource
    configuration since computing them reads each extension's package
    metadata from disk.
    """
    if config.autoreload:
        return _bundle_extensions(None, resources)
    key = (
        resources.mode, resources.root_url, resources.minified, _settings.dev,
        model_registry_key()
    )
    if key in _EXTENSION_BUNDLES:
        return list(_EXTENSION_BUNDLES[key])
    return list(remember(_EXTENSION_BUNDLES, key, _bundle_extensions(None, resources)))



def _resource_key(url: str) -> str:
    """
    Normalizes a resource url for duplicate detection: the scheme, a leading
    ./ and the ?v= cache buster do not make it a different file.
    """
    url = str(url)
    url = re.sub(r'^(https?:)?//', '', url)
    url = url.removeprefix('./')
    return re.sub(r'\?v=[^&#]*$', '', url)


def dedupe_template_resources(
    template_resources: ResourcesType, bundle: BkBundle
) -> ResourcesType:
    """
    Drops template resources the page already loads through the bundle,
    or earlier in the template resources, keeping the remaining order.

    A design's resources are declared on the Document bundle and on the
    template rendering it, so without this a template page loads e.g. the
    fast-components module and the font stylesheet twice.
    """
    seen = {
        _resource_key(url) for url in (
            list(bundle.js_files) + list(getattr(bundle, 'js_modules', [])) +
            list(bundle.css_files)
        )
    }
    deduped = t.cast('ResourcesType', dict(template_resources))
    for rtype in ('js', 'js_modules', 'css'):
        resources = template_resources.get(rtype)
        if not resources:
            continue
        kept: dict[str, str] = {}
        for name, url in resources.items():  # type: ignore
            key = _resource_key(url)
            if key in seen:
                continue
            seen.add(key)
            kept[name] = url
        deduped[rtype] = kept  # type: ignore
    return deduped


def bundle_resources(
    roots,
    resources: BkResources,
    notebook: bool = False,
    reloading: bool = False,
    enable_mathjax: bool | t.Literal['auto'] = 'auto'
):
    from ..config import panel_extension as ext
    global RESOURCE_MODE
    panel_resources = (
        resources if isinstance(resources, Resources) else
        Resources.from_bokeh(resources, notebook=notebook)
    )
    RESOURCE_MODE = mode = panel_resources.mode if panel_resources is not None else "inline"

    models = _reachable_models(roots) if roots else set()

    if isinstance(enable_mathjax, bool):
        use_mathjax = enable_mathjax
    elif roots:
        use_mathjax = (
            'mathjax' in ext._loaded_extensions or
            _use_mathjax(models) or
            _panel_use_mathjax(models)
        )
    else:
        use_mathjax = 'mathjax' in ext._loaded_extensions

    # Notebooks load resources before anything is rendered, so we cannot
    # know whether a table will be displayed later and always load it
    use_tables = (
        notebook or roots is None or 'bokeh-tables' in ext._loaded_extensions or
        _panel_use_tables(models)
    )

    # Everything below only depends on the resources, the session configuration
    # and which models are registered, so a repeat request reuses the bundle.
    bundle: dict[str, t.Any]
    if config.autoreload:
        bundle = _build_bundle(panel_resources, mode, reloading, use_mathjax, use_tables)
    else:
        key = _bundle_key(panel_resources, reloading, use_mathjax, use_tables)
        cached = _BUNDLE_CACHE.get(key)
        if cached is None:
            cached = remember(
                _BUNDLE_CACHE, key, _build_bundle(panel_resources, mode, reloading, use_mathjax, use_tables)
            )
        bundle = cached
    return Bundle(
        css_files=list(bundle['css_files']),
        css_raw=list(bundle['css_raw']),
        hashes=dict(bundle['hashes']),
        js_files=list(bundle['js_files']),
        js_raw=list(bundle['js_raw']),
        js_module_exports=dict(bundle['js_module_exports']),
        js_modules=list(bundle['js_modules']),
        resource_declarations=bundle['resource_declarations'],
        notebook=notebook,
    )


_BUNDLE_CACHE: dict[tuple, dict[str, t.Any]] = {}

def _bundle_key(resources: Resources, reloading: bool, use_mathjax: bool, use_tables: bool) -> tuple:
    extensions = state._extensions
    notifications = state.notifications if config.notifications else None
    return (
        resources.mode, resources.version, resources.minified, resources.dev,
        resources.log_level, resources._root_url, tuple(resources.components),
        resources.base_dir, resources.root_dir, resources.absolute,
        resources.notebook, resources.path_versioner,
        reloading, use_mathjax, use_tables,
        state.rel_path, state.base_url, state._is_pyodide, state._is_server_session,
        None if extensions is None else frozenset(extensions),
        tuple(extension._loaded_extensions), frozenset(loaded_custom_classes()),
        config.design, tuple(config.css_files), tuple(config.js_files.items()),
        tuple(config.js_modules.items()), tuple(config.raw_css), tuple(config.global_css),
        config.global_loading_spinner, config.loading_spinner, config.loading_color,
        config.loading_max_height, config.npm_cdn, config.lazy_resources,
        config.notebook_resources, config.inline,
        tuple(notifications._stylesheets) if notifications else None,
        jupyter_endpoint_available(), NOTEBOOK_RESOURCES, _settings.dev,
        _settings.resources(default='server'), model_registry_key(), len(EXTENSION_CDN),
    )


def _build_bundle(
    resources: Resources, mode: str, reloading: bool, use_mathjax: bool, use_tables: bool
) -> dict[str, t.Any]:
    js_resources = css_resources = resources

    js_files = []
    js_raw = []
    css_files = []
    css_raw = []

    if js_resources:
        js_resources = js_resources.clone()
        if not use_mathjax and "bokeh-mathjax" in js_resources.components:
            js_resources.components.remove("bokeh-mathjax")
        if not use_tables and "bokeh-tables" in js_resources.components:
            js_resources.components.remove("bokeh-tables")
        if reloading:
            js_resources.components.clear()

        js_files.extend(js_resources.js_files)
        js_raw.extend(js_resources.js_raw)

    css_files.extend(css_resources.css_files)
    css_raw.extend(css_resources.css_raw)

    extensions = _extension_bundles(js_resources)
    if reloading:
        extensions = [
            ext for ext in extensions if not (ext.cdn_url is not None and str(ext.cdn_url).startswith('https://unpkg.com/@holoviz/panel@'))
        ]

    extra_js = []
    if mode == "inline":
        js_raw.extend([ Resources._inline(bundle.artifact_path) for bundle in extensions ])
    elif mode == "server":
        for bundle in extensions:
            server_url = str(bundle.server_url)
            if resources.root_url and not resources.absolute:
                server_url = server_url.replace(resources.root_url, '', 1)
                if state.rel_path:
                    server_url = f'{state.rel_path}/{server_url}'
            js_files.append(server_url)
    elif mode == "cdn":
        for bundle in extensions:
            if bundle.cdn_url is not None:
                extra_js.append(str(bundle.cdn_url))
            else:
                js_raw.append(Resources._inline(bundle.artifact_path))
    else:
        extra_js.extend([str(bundle.artifact_path) for bundle in extensions])
    js_files += resources.adjust_paths(extra_js)

    extension = bundle_models(None)
    if extension is not None:
        js_raw.append(extension)

    hashes = js_resources.hashes if js_resources else {}

    return dict(
        css_files=[URL(css_file) for css_file in css_files],
        css_raw=css_raw,
        hashes=hashes,
        js_files=[URL(js_file) for js_file in js_files],
        js_raw=js_raw,
        js_module_exports=resources.js_module_exports,
        js_modules=resources.js_modules,
        resource_declarations=resources.resource_declarations,
    )


class ResourceComponent:
    """
    Mix-in class for components that define a set of resources
    that have to be resolved.
    """

    _resources: t.ClassVar[ResourcesType] = {
        'css': {},
        'font': {},
        'js': {},
        'js_modules': {},
        'raw_css': [],
    }

    @classmethod
    def _resolve_resource(
        cls,
        resource_type: str,
        resource: str,
        cdn: bool = False
    ) -> str:
        dist_path = get_dist_path(cdn=cdn)
        if resource.startswith(CDN_DIST):
            resource_path = resource.replace(f'{CDN_DIST}bundled/', '')
        elif resource.startswith(config.npm_cdn):
            resource_path = resource.replace(config.npm_cdn, '')[1:]
        elif resource.startswith('http:'):
            resource_path = url_path(resource)
        else:
            resource_path = resource

        if resource_type == 'js_modules' and not (state.rel_path or cdn):
            prefixed_dist = f'./{dist_path}'
        else:
            prefixed_dist = dist_path

        bundlepath = BUNDLE_DIR / resource_path.replace('/', os.path.sep)
        # Windows may trigger OSError: [WinError 123]
        try:
            is_file = bundlepath.is_file()
        except Exception:
            is_file = False
        if is_file or (state._is_pyodide and not isurl(resource)):
            # Versioned so the server may cache it; a module keeps its
            # bare url since relative imports between modules would
            # otherwise load a second instance of it.
            version = f'?v={JS_VERSION}' if resource_type in ('js', 'css') and not cdn else ''
            return f'{prefixed_dist}bundled/{resource_path}{version}'
        elif isurl(resource):
            return resource
        elif resolve_custom_path(cls, resource):
            return component_resource_path(
                cls, f'_resources/{resource_type}', resource
            )
        raise FileNotFoundError(
            f'Could not resolve resource {resource!r}'
        )

    def resolve_resources(
        self,
        cdn: bool | t.Literal['auto'] = 'auto',
        extras: dict[str, dict[str, str]] | None = None
    ) -> ResourcesType:
        """
        Resolves the resources required for this component.

        Parameters
        ----------
        cdn: bool | Literal['auto']
            Whether to load resources from CDN or local server. If set
            to 'auto' value will be automatically determine based on
            global settings.
        extras: dict[str, dict[str, str]] | None
            Additional resources to add to the bundle. Valid resource
            types include js, js_modules and css.

        Returns
        -------
        Dictionary containing JS and CSS resources.
        """
        cls = type(self)
        resources: ResourcesType = {}
        for rt, res in self._resources.items():
            if not isinstance(res, dict):
                continue
            if rt == 'font':
                rt = 'css'
            res = {
                name: url if isurl(url) else f'{cls.__name__.lower()}/{url}'
                for name, url in res.items()
            }
            if rt in resources:
                resources[rt] = dict(resources[rt], **res)  # type: ignore
            else:
                resources[rt] = res  # type: ignore

        resource_types: ResourcesType = {
            'js': {},
            'js_modules': {},
            'css': {},
            'raw_css': []
        }

        cdn = use_cdn() if cdn == 'auto' else cdn
        for resource_type in resource_types:
            if resource_type not in resources or resource_type == 'raw_css':  # type: ignore
                continue
            resource_files = resource_types[resource_type]  # type: ignore
            for rname, resource in resources[resource_type].items():  # type: ignore
                resolved_resource = self._resolve_resource(
                    resource_type, resource, cdn=cdn
                )
                if resolved_resource:
                    resource_files[rname] = resolved_resource  # type: ignore

        version_suffix = f'?v={JS_VERSION}'
        dist_path = get_dist_path(cdn=cdn)
        for resource_type, extra_resources in (extras or {}).items():
            resource_files = resource_types[resource_type]  # type: ignore
            for name, res in extra_resources.items():
                if not cdn:
                    res = res.replace(CDN_DIST, dist_path)
                    if not res.endswith(version_suffix):
                        res += version_suffix
                resource_files[name] = res

        return resource_types


class Resources(BkResources):

    def __init__(self, *args, absolute=False, notebook=False, **kwargs):
        self.absolute = absolute
        self.notebook = notebook
        super().__init__(*args, **kwargs)

    @classmethod
    def from_bokeh(cls, bkr, absolute=False, notebook=False):
        kwargs = {}
        if bkr.mode.startswith("server"):
            kwargs['root_url'] = bkr.root_url

        components = bkr.components if hasattr(bkr, 'components_for') else bkr._components
        return cls(
            mode=bkr.mode, version=bkr.version, minified=bkr.minified,
            log_level=bkr.log_level, notebook=notebook,
            path_versioner=bkr.path_versioner,
            components=components, base_dir=bkr.base_dir,
            root_dir=bkr.root_dir, absolute=absolute, **kwargs
        )

    def _collect_external_resources(self, resource_attr: ResourceAttr) -> list[str]:
        """ Collect external resources set on resource_attr attribute of all models."""
        external_resources: list[str] = []

        for cls in sorted_model_classes():
            if not extension_declared(cls):
                continue
            external: list[str] | str | None = getattr(cls, resource_attr, None)

            if isinstance(external, str):
                if external not in external_resources:
                    external_resources.append(external)
            elif isinstance(external, list):
                for e in external:
                    if e not in external_resources:
                        external_resources.append(e)

        return external_resources

    @property
    def _jupyter_endpoint(self) -> bool:
        # Embedders such as nteract pass notebook=True without serving
        # the endpoint, so the flag alone must not trigger the rewrite.
        return self.notebook and jupyter_endpoint_available()

    def _cdn_urls(self) -> Urls:
        # BokehJS is served by the extension's static handler as well, so
        # asking Bokeh for server urls rooted there keeps its own naming
        # and cache busting rather than rewriting the CDN urls after the
        # fact, which depend on the release channel and version string.
        if self._jupyter_endpoint:
            from bokeh.server.views.static_handler import StaticHandler
            return _get_server_urls(
                jupyter_endpoint_root(),
                False if self.dev else self.minified,
                StaticHandler.append_version
            )
        return super()._cdn_urls()

    def jupyter_cdn_map(self) -> list[tuple[str, str]]:
        """
        Pairs of paths relative to the Jupyter server extension root and
        the CDN urls serving the same files.

        Lets the notebook bootstrap load the files from the CDN when the
        endpoint cannot serve them, e.g. in an exported notebook.
        """
        cdn_map = extension_cdn_map()
        minified = False if self.dev else self.minified
        components = list(self.components)
        cdn_urls = super()._cdn_urls().urls(components, 'js')
        server_urls = _get_server_urls('', minified).urls(components, 'js')
        cdn_map.extend(zip(server_urls, cdn_urls, strict=True))
        return cdn_map

    def _server_urls(self) -> Urls:
        return _get_server_urls(
            self.root_url if self.absolute else '',
            False if self.dev else self.minified,
            self.path_versioner
        )

    def extra_resources(self, resources, resource_type):
        """
        Adds resources for ReactiveHTML components.
        """
        from ..reactive import ReactiveCustomBase
        for model in _descendents(ReactiveCustomBase, concrete=True):
            cls_files = getattr(model, resource_type, None)
            if not (cls_files and model._loaded()):
                continue
            for cls in model.__mro__[1:]:
                supcls_files = getattr(cls, resource_type, [])
                if supcls_files == cls_files:
                    model = cls
            for resource in getattr(model, resource_type, []):
                if isinstance(resource, pathlib.PurePath):
                    continue
                if self.mode == 'cdn' and not self._jupyter_endpoint:
                    resource = resolve_resource_cdn(resource)
                if state.rel_path:
                    resource = resource.removeprefix(state.rel_path+'/')
                if not isurl(resource) and not resource.lstrip('./').startswith('static/extensions'):
                    resource = component_resource_path(model, resource_type, resource)
                if resource not in resources:
                    resources.append(resource)

    def adjust_paths(self, resources):
        """
        Computes relative and absolute paths for resources.
        """
        new_resources = []
        version_suffix = f'?v={JS_VERSION}'
        cdn_base = f'{config.npm_cdn}/@holoviz/panel@{JS_VERSION}/dist/'
        endpoint = jupyter_endpoint_root() if self._jupyter_endpoint else None
        for resource in resources:
            if not isinstance(resource, str):
                resource = str(resource)
            if endpoint and resource.startswith(endpoint):
                new_resources.append(resource)
                continue
            resource = resource.replace('https://unpkg.com', config.npm_cdn)
            if resource.startswith(cdn_base):
                resource = resource.replace(cdn_base, CDN_DIST)
            if self.mode == 'cdn':
                resource = resolve_resource_cdn(resource)
            if self.mode == 'server':
                resource = resource.replace(CDN_DIST, LOCAL_DIST)
            if resource.startswith((state.base_url, "static/")):
                if resource.startswith(state.base_url):
                    resource = resource[len(state.base_url):]
                if state.rel_path:
                    resource = f'{state.rel_path}/{resource}'
                elif self.absolute and self.mode == 'server':
                    resource = f'{self.root_url}{resource}'
            if resource.endswith('.css') and not resource.startswith(('http:', 'https:')):
                resource += version_suffix
            if endpoint:
                if resource.startswith(CDN_DIST):
                    resource = f'{endpoint}{LOCAL_DIST}' + resource.removeprefix(CDN_DIST)
                elif resource.startswith('static/extensions/'):
                    resource = f'{endpoint}{resource}'
            new_resources.append(resource)
        return new_resources

    def clone(self, *, components=None) -> Resources:
        """
        Make a clone of a resources instance allowing to override its components.
        """
        return Resources(
            mode=self.mode,
            version=self.version,
            root_dir=self.root_dir,
            dev=self.dev,
            minified=self.minified,
            log_level=self.log_level,
            root_url=self._root_url,
            path_versioner=self.path_versioner,
            components=components if components is not None else list(self.components),
            base_dir=self.base_dir,
            notebook=self.notebook,
            absolute=self.absolute
        )

    @property
    def dist_dir(self):
        if self.notebook and self.mode == 'server':
            dist_dir = '/panel-preview/static/extensions/panel/'
        elif self.mode == 'server':
            if state.rel_path:
                dist_dir = f'{state.rel_path}/{LOCAL_DIST}'
            else:
                dist_dir = LOCAL_DIST
            if self.absolute:
                dist_dir = f'{self.root_url}{dist_dir}'
        else:
            dist_dir = CDN_DIST
        return dist_dir

    @property
    def css_files(self):
        from ..config import config

        files = super().css_files
        self.extra_resources(files, '__css__')
        self.extra_resources(files, '_bundle_css')
        if config.notifications and state.notifications:
            files += state.notifications._stylesheets
        css_files = self.adjust_paths([
            css for css in files if self.mode != 'inline' or not is_cdn_url(css)
        ])
        if config.design:
            css_files += list(config.design._resources.get('font', {}).values())
        for cssf in config.css_files:
            if os.path.isfile(cssf) or cssf in files:
                continue
            css_files.append(cssf)
        return css_files

    @property
    def css_raw(self):
        from ..config import config
        raw = super().css_raw

        # Inline local dist resources
        css_files = self._collect_external_resources("__css__")
        self.extra_resources(css_files, '__css__')
        if self.mode.lower() not in ('server', 'cdn'):
            raw += [
                (DIST_DIR / css.replace(CDN_DIST, '')).read_text(encoding='utf-8')
                for css in css_files if is_cdn_url(css)
            ]

        # Add local CSS files
        for cssf in config.css_files:
            if not os.path.isfile(cssf):
                continue
            css_txt = process_raw_css([Path(cssf).read_text(encoding='utf-8')])[0]
            if css_txt not in raw:
                raw.append(css_txt)

        # Add loading spinner
        if config.global_loading_spinner:
            from .loading import loading_resources
            raw.extend(loading_resources(inline=True, dist_path=self.dist_dir)['raw_css'])
        return raw + process_raw_css(config.raw_css) + process_raw_css(config.global_css)

    @property
    def js_files(self):
        from ..config import config

        # Gather JS files
        with set_resource_mode(self.mode):
            files = super().js_files
            self.extra_resources(files, '__javascript__')
        files += [js for js in config.js_files.values()]
        if config.design:
            design_js = config.design().resolve_resources(
                cdn=self.notebook or 'auto', include_theme=False
            )['js'].values()
            files += [res for res in design_js if res not in files]

        # Filter and adjust JS file urls
        js_files = self.adjust_paths([
            js for js in files if self.mode != 'inline' or not is_cdn_url(js)
        ])

        # Load requirejs last to avoid interfering with other libraries
        require_index = [i for i, jsf in enumerate(js_files) if 'require' in jsf]
        if require_index:
            requirejs = js_files.pop(require_index[0])
            js_files.append(requirejs)

        return js_files

    @property
    def js_modules(self):
        from ..config import config
        from ..reactive import ReactiveCustomBase

        modules = list(config.js_modules.values())
        for model in Model.model_class_reverse_map.values():
            if not hasattr(model, '__javascript_modules__') or not extension_declared(model):
                continue
            for module in model.__javascript_modules__:
                if module not in modules:
                    modules.append(module)

        self.extra_resources(modules, '__javascript_modules__')
        if config.design:
            design_resources = config.design().resolve_resources(
                cdn=self.notebook or 'auto', include_theme=False
            )
            modules += [
                res for res in design_resources['js_modules'].values()
                if res not in modules
            ]

        for model in _descendents(ReactiveCustomBase, concrete=True):
            if not (getattr(model, '__javascript_modules__', None) and model._loaded()):
                continue
            for js_module in model.__javascript_modules__:
                if state.rel_path:
                    js_module = js_module.removeprefix(state.rel_path+'/')
                if not isurl(js_module) and not js_module.startswith('static/extensions'):
                    js_module = component_resource_path(model, '__javascript_modules__', js_module)
                if js_module not in modules:
                    modules.append(js_module)

        return self.adjust_paths(modules)

    @property
    def js_module_exports(self):
        modules = {}
        for model in Model.model_class_reverse_map.values():
            if hasattr(model, '__javascript_module_exports__') and extension_declared(model):
                modules.update(dict(zip(model.__javascript_module_exports__, model.__javascript_modules__)))
        return dict(zip(modules, self.adjust_paths(modules.values())))

    @property
    def js_raw(self):
        raw_js = super().js_raw
        if not self.mode == 'inline':
            return raw_js

        # Inline local dist resources
        js_files = self._collect_external_resources("__javascript__")
        self.extra_resources(js_files, '__javascript__')
        raw_js += [
            (DIST_DIR / js.replace(CDN_DIST, '')).read_text(encoding='utf-8')
            for js in js_files if is_cdn_url(js)
        ]

        # Inline config.js_files
        from ..config import config
        raw_js += [
            Path(js).read_text(encoding='utf-8') for js in config.js_files.values()
            if os.path.isfile(js)
        ]

        # Inline config.design JS resources
        if config.design:
            design_js = config.design().resolve_resources(
                cdn=True, include_theme=False
            )['js'].values()
            raw_js += [
                (DIST_DIR / js.replace(CDN_DIST, '')).read_text(encoding='utf-8')
                for js in design_js if is_cdn_url(js)
            ]
        return raw_js

    @property
    def resource_declarations(self):
        from .resource_spec import declared_specs
        return declared_specs(self.mode)

    @property
    def render_js(self):
        return JS_RESOURCES.render(
            js_raw=self.js_raw, js_files=self.js_files,
            js_modules=module_tags(self.js_modules, self.js_module_exports),
            hashes=self.hashes,
            resource_declarations=self.resource_declarations
        )


class Bundle(BkBundle):

    def __init__(self, notebook=False, **kwargs):
        self.js_modules = kwargs.pop("js_modules", [])
        self.js_module_exports = kwargs.pop("js_module_exports", {})
        self.resource_declarations = kwargs.pop("resource_declarations", {})
        self.notebook = notebook
        super().__init__(**kwargs)

    @classmethod
    def from_bokeh(cls, bk_bundle, notebook=False):
        return cls(
            notebook=notebook,
            js_files=bk_bundle.js_files,
            js_raw=bk_bundle.js_raw,
            css_files=bk_bundle.css_files,
            css_raw=bk_bundle.css_raw,
            hashes=bk_bundle.hashes,
        )

    @property
    def js_module_tags(self):
        return module_tags(self.js_modules, self.js_module_exports)

    def _render_css(self) -> str:
        return BkCSS_RESOURCES.render(
            css_files=self.css_files,
            css_raw=self.css_raw
        )

    def _render_js(self):
        return JS_RESOURCES.render(
            js_raw=self.js_raw,
            js_files=self.js_files,
            js_modules=module_tags(self.js_modules, self.js_module_exports),
            resource_declarations=self.resource_declarations,
            hashes=self.hashes
        )
