"""
Derives the client-side resource specification for component classes.

The specification is the payload the browser needs in order to load a
component's external libraries on demand. It is derived entirely from the
declarations components already make (``__javascript_raw__``,
``__javascript_modules_raw__``, ``__javascript_module_exports__``,
``__css_raw__`` and ``__js_skip__``), so third-party component authors get
lazy loading without any new API.

The same specification feeds both delivery paths:

* the lazy path, where it is carried by the ``external_resources`` property
  of a model instance and resolved by the client-side registry, and
* the eager path, where ``pn.extension`` renders the script and link tags
  into the page and the templates call ``declare()`` on the registry with
  the specs it just satisfied.

Generating both from one function is what keeps them from drifting.
"""
from __future__ import annotations

import copy
import pathlib
import re
import typing as t

from functools import lru_cache

from bokeh.embed.bundle import extension_dirs

from ..config import config
from ..util import isurl
from .resources import (
    EXTENSION_CDN, Resources, component_resource_path, extension_cdn_map,
    extension_declared, get_notebook_resources, get_resource_mode,
    jupyter_endpoint_available, loaded_custom_classes, model_registry_key,
    remember, resolve_resource_cdn, set_resource_mode, sorted_model_classes,
)
from .state import state

if t.TYPE_CHECKING:
    from .resources import MODES

# Version of the specification format. The client-side registry is shared
# across Panel versions on a single page, so this has to be bumped in
# lockstep with any backwards incompatible change to the payload shape.
SPEC_VERSION = 1

# Attributes whose presence anywhere in the MRO means a class may declare
# resources. Checked against ``__dict__`` so that ``classproperty``
# declarations are not evaluated, which is what makes the common case (a
# model with no resources at all) cheap.
_RESOURCE_ATTRS = (
    '__javascript_raw__',
    '__javascript__',
    '__javascript_modules_raw__',
    '__javascript_modules__',
    '__css_raw__',
    '__css__',
)

_CUSTOM_ELEMENT_RE = re.compile(r"^customElements\.get\(\s*['\"]([^'\"]+)['\"]\s*\)\s*$")

_SPEC_CACHE: dict[t.Any, dict[str, t.Any] | None] = {}
_DECLARED_CACHE: dict[t.Any, dict[str, t.Any]] = {}


class _Entry(t.NamedTuple):
    kind: t.Literal['js', 'module']
    raw: str
    url: str
    export: str | None


def _spec_mode(mode: MODES | None = None) -> tuple[str, bool]:
    """
    Resolves the mode urls should be generated for.

    ``inline`` has no urls to hand out, so it falls back to the CDN form
    and flags the specification, which the loader reports at debug level.
    """
    resolved = mode or get_resource_mode()
    if resolved == 'inline':
        return 'cdn', True
    return resolved, False


def _resources(mode: str) -> Resources:
    # `NOTEBOOK_RESOURCES` is a process-wide default set by the notebook's
    # own bootstrap, so it isn't scoped to that notebook's document. A
    # server started from the same kernel process (e.g. `pn.serve(...,
    # threaded=True)`) must not inherit it, or every lazily-loaded resource
    # would 404 against an endpoint that server never registers.
    notebook = get_notebook_resources() and not state._is_server_session
    return Resources(mode=mode, notebook=notebook)


def _parse_probe(expression: str) -> dict[str, str] | None:
    """
    Converts a ``__js_skip__`` key into a structured probe.

    ``__js_skip__`` keys are JavaScript expressions today, e.g.
    ``Perspective`` uses ``customElements.get('perspective-viewer')``.
    Structuring them means nothing has to be evaluated client-side, which
    keeps strict CSP deployments (no ``unsafe-eval``) working.
    """
    expression = expression.strip()
    match = _CUSTOM_ELEMENT_RE.match(expression)
    if match:
        return {'custom_element': match.group(1)}
    if expression.isidentifier():
        return {'global': expression}
    return None


def _js_skip(cls: type) -> dict[str, list[str]]:
    """
    Reads ``__js_skip__``, tolerating the broken declarations out there.
    """
    try:
        skip = getattr(cls, '__js_skip__', None) or {}
    except Exception:
        return {}
    if not isinstance(skip, dict):
        return {}
    resolved = {}
    for key, urls in skip.items():
        if isinstance(urls, str):
            urls = [urls]
        elif not isinstance(urls, (list, tuple)):
            continue
        resolved[key] = [url for url in urls if isinstance(url, str)]
    return resolved


def _bokeh_pairs(
    cls: type, attr: str, resources: Resources
) -> list[tuple[str, str]]:
    """
    Pairs a Bokeh model class' declared urls with their resolved form.

    The declared (``bundled_files``) form is what ``__js_skip__`` refers
    to, the resolved (``adjust_paths``) form is what the browser fetches,
    so grouping needs both.
    """
    try:
        raw = getattr(cls, attr, None) or []
    except Exception:
        return []
    raw = [url for url in raw if isinstance(url, str)]
    return list(zip(raw, resources.adjust_paths(raw)))


def _panel_pairs(
    cls: type, attr: str, resources: Resources
) -> list[tuple[str, str]]:
    """
    Same as ``_bokeh_pairs`` for ``ReactiveHTML``/``ReactiveESM`` classes.

    Their resources are declared on the Panel class rather than the shared
    Bokeh model, and are resolved the way ``Resources.extra_resources``
    resolves them, i.e. relative paths become component resource urls.
    """
    try:
        declared = getattr(cls, attr, None) or []
    except Exception:
        return []

    # extra_resources attributes the resources to the class that declared
    # them, so that component resource urls point at the right module.
    owner = cls
    for supcls in cls.__mro__[1:]:
        if getattr(supcls, attr, None) == declared:
            owner = supcls

    raw, resolved = [], []
    for resource in declared:
        if isinstance(resource, pathlib.PurePath) or not isinstance(resource, str):
            continue
        url = resource
        if resources.mode == 'cdn':
            url = str(resolve_resource_cdn(url))
        if state.rel_path:
            url = url.removeprefix(state.rel_path+'/')
        if not isurl(url) and not url.lstrip('./').startswith('static/extensions'):
            url = component_resource_path(owner, attr, url)
        raw.append(resource)
        resolved.append(url)
    return list(zip(raw, resources.adjust_paths(resolved)))


def _declaring_owner(cls: type) -> type:
    """
    The class in the MRO that declared the resources, most derived first.

    Naming anonymous groups after it rather than after ``cls`` is what makes
    the three ESM models (which all inherit es-module-shims from
    ``ReactiveESM``) share one group instead of declaring three.
    """
    for supcls in getattr(cls, '__mro__', (cls,)):
        if any(attr in supcls.__dict__ for attr in _RESOURCE_ATTRS):
            return supcls
    return cls


def _build_libs(cls: type, entries: list[_Entry], skip: dict[str, list[str]]) -> list[dict]:
    """
    Groups a class' urls into libraries, one per global they provide.

    ``__js_skip__`` maps a global name to the subset of urls providing it,
    which is exactly the grouping wanted. Urls no global claims become one
    anonymous group loaded in declared order (deck.gl's loaders, filepond's
    plugins, echarts-gl).
    """
    index_of: dict[str, int] = {}
    for i, entry in enumerate(entries):
        index_of.setdefault(entry.raw, i)

    probes: dict[str, dict[str, str]] = {}
    order: dict[str, int] = {}
    group_of: dict[str, str] = {}
    for expression, urls in skip.items():
        probe = _parse_probe(expression)
        if probe is None:
            continue
        indices = [index_of[url] for url in urls if url in index_of]
        if not indices:
            continue
        name = probe.get('global') or probe['custom_element']
        probes[name] = probe
        order[name] = min(order.get(name, len(entries)), min(indices))
        for url in urls:
            if url in index_of:
                group_of.setdefault(url, name)

    anonymous = f'{_declaring_owner(cls).__name__.lower()}:extra'
    for i, entry in enumerate(entries):
        if entry.raw not in group_of:
            group_of[entry.raw] = anonymous
            order.setdefault(anonymous, i)

    libs: dict[str, dict[str, t.Any]] = {}
    for entry in entries:
        name = group_of[entry.raw]
        lib = libs.setdefault(name, {'name': name})
        if entry.kind == 'js':
            lib.setdefault('js', []).append(entry.url)
        else:
            module: dict[str, str] = {'url': entry.url}
            if entry.export:
                module['export'] = entry.export
            lib.setdefault('modules', []).append(module)
    for name, probe in probes.items():
        if name in libs:
            libs[name]['probe'] = probe

    return [libs[name] for name in sorted(libs, key=lambda name: order[name])]


def _shim_url(resources: Resources) -> str | None:
    """
    The es-module-shims url, needed before any module can be imported.

    Today the shim only reaches the page if ``ReactiveESM.__javascript__``
    happened to be collected, so a notebook that never used an ESM
    component has no ``importShim`` at all. Carrying it on any spec that
    contains modules closes that gap.
    """
    from ..models.esm import ReactiveESM
    urls = resources.adjust_paths(ReactiveESM.__javascript__)
    return urls[0] if urls else None


def _is_esm(cls: type) -> bool:
    from ..custom import ReactiveESM
    return isinstance(cls, type) and issubclass(cls, ReactiveESM)


@lru_cache(maxsize=None)
def _declares_resources(cls: type) -> bool:
    # ReactiveCustomBase declares every attribute as None.
    mro = getattr(cls, '__mro__', (cls,))
    return any(
        supcls.__dict__.get(attr) is not None
        for attr in _RESOURCE_ATTRS
        for supcls in mro
    )


@lru_cache(maxsize=None)
def _has_resources(cls: type) -> bool:
    # Every ESM component imports through es-module-shims, which a host
    # that renders the output itself may not have loaded.
    return _is_esm(cls) or _declares_resources(cls)


def _spec_cdn_map(spec: dict[str, t.Any]) -> list[list[str]]:
    """
    The entries of the extension CDN map the urls of a spec fall under,
    since the spec is serialized with every model instance.
    """
    urls = [
        url for lib in spec.get('libs', [])
        for url in (*lib.get('js', []), *(module['url'] for module in lib.get('modules', [])))
    ]
    urls += spec.get('css', [])
    if 'shim' in spec:
        urls.append(spec['shim'])
    return [
        [prefix, cdn] for prefix, cdn in extension_cdn_map()
        if any(prefix in url for url in urls)
    ]


def _build_spec(cls: type, mode: str) -> dict[str, t.Any] | None:
    from ..reactive import ReactiveCustomBase

    with set_resource_mode(mode):  # type: ignore[arg-type]
        resources = _resources(mode)
        pairs = _panel_pairs if issubclass(cls, ReactiveCustomBase) else _bokeh_pairs
        js = pairs(cls, '__javascript__', resources)
        modules = pairs(cls, '__javascript_modules__', resources)
        css = [url for _, url in pairs(cls, '__css__', resources)]
        try:
            exports = list(getattr(cls, '__javascript_module_exports__', None) or [])
        except Exception:
            exports = []
        skip = _js_skip(cls)

        entries = [_Entry('js', raw, url, None) for raw, url in js]
        entries += [
            _Entry('module', raw, url, exports[i] if i < len(exports) else None)
            for i, (raw, url) in enumerate(modules)
        ]

        esm = _is_esm(cls)
        if not entries and not css and not esm:
            return None

        spec: dict[str, t.Any] = {'v': SPEC_VERSION}
        if entries:
            spec['libs'] = _build_libs(cls, entries, skip)
        if css:
            spec['css'] = css
        if modules or esm:
            shim = _shim_url(resources)
            if shim:
                spec['shim'] = shim
        if mode == 'server' and (cdn_map := _spec_cdn_map(spec)):
            # Server urls only resolve where something serves Panel's
            # extension routes, which a host embedding the output itself
            # (e.g. Shiny via jupyter_bokeh) may not do.
            spec['cdn'] = cdn_map
        return spec


def resource_spec(cls: type, mode: MODES | None = None) -> dict[str, t.Any] | None:
    """
    Builds the client-side resource specification for a component class.

    Groups the class' ``__javascript__`` urls by the global they provide
    (from ``__js_skip__``), resolves them for the active resource mode via
    the same ``bundled_files``/``adjust_paths`` machinery the eager path
    uses, and appends ``__javascript_modules__`` (with their
    ``__javascript_module_exports__`` names) and ``__css__``.

    Parameters
    ----------
    cls: type
        A Bokeh model class, or a ``ReactiveHTML``/``ReactiveESM``
        subclass, whose resources are declared on the Panel class.
    mode: MODES | None
        Resource mode to resolve urls for, defaulting to the active one.

    Returns
    -------
    The specification, or None if the class declares no resources or lazy
    loading is disabled.
    """
    if not config.lazy_resources or not _has_resources(cls):
        return None
    resolved_mode, inline_fallback = _spec_mode(mode)
    # The effective notebook default has to be part of the key too: a
    # notebook and a server started from it can share `rel_path`/`base_url`
    # while only one of them is a genuine server session (see `_resources`).
    # Whether the Jupyter endpoint serves the urls can be toggled with
    # `config.notebook_resources`, and the extension registries feed the
    # server-mode `cdn` map and grow as extensions are imported.
    key = (
        cls, resolved_mode, state.rel_path, state.base_url,
        get_notebook_resources() and not state._is_server_session,
        tuple(getattr(cls, '__css_raw__', None) or ()),
        jupyter_endpoint_available(), config.npm_cdn, len(EXTENSION_CDN),
        len(extension_dirs),
    )
    if key in _SPEC_CACHE:
        spec = _SPEC_CACHE[key]
    else:
        spec = _SPEC_CACHE[key] = _build_spec(cls, resolved_mode)
    if spec is None:
        return None
    spec = copy.deepcopy(spec)
    spec['timeout'] = config.resource_timeout
    if inline_fallback:
        spec['inline_fallback'] = True
    return spec


def lazy_load_available(notebook: bool = False) -> bool:
    """
    Whether a component that was not declared can still get its resources.

    False when lazy loading was switched off, and for self-contained
    ``inline`` output, where there is nothing left to inline after the fact
    and the component would silently fall back to the CDN. Notebooks are
    exempt from the latter: their output is never self-contained anyway.
    """
    if not config.lazy_resources:
        return False
    return notebook or get_resource_mode() != 'inline'


def _resource_classes() -> list[type]:
    """
    The classes whose resources the eager path has put on the page.

    Mirrors ``Resources._collect_external_resources`` and
    ``Resources.extra_resources``, extension gate included, so that what
    is declared to the registry is exactly what was rendered.
    """
    classes = [cls for cls in sorted_model_classes() if extension_declared(cls)]
    return classes + loaded_custom_classes()


def _declared_key(mode: str) -> tuple:
    """
    Everything ``declared_specs`` depends on besides the class declarations
    themselves, which only change when a class is registered or loaded.
    """
    extensions = state._extensions
    return (
        mode, state.rel_path, state.base_url,
        get_notebook_resources() and not state._is_server_session,
        jupyter_endpoint_available(), config.npm_cdn, len(EXTENSION_CDN),
        None if extensions is None else frozenset(extensions),
        model_registry_key(), frozenset(loaded_custom_classes()),
    )


def declared_specs(mode: MODES | None = None) -> dict[str, t.Any]:
    """
    The resources the eager path has already satisfied.

    Rendered into the page (and the notebook bootstrap) as a ``declare()``
    call so that the registry knows about them without having to infer it
    from the DOM, which is the only thing that works in ``inline`` mode,
    where the libraries were inlined and have no urls at all.
    """
    if not config.lazy_resources:
        return {}
    resolved_mode, _ = _spec_mode(mode)
    key = _declared_key(resolved_mode)
    if key in _DECLARED_CACHE:
        return copy.deepcopy(_DECLARED_CACHE[key])
    return copy.deepcopy(remember(_DECLARED_CACHE, key, _build_declared(resolved_mode)))


def _build_declared(resolved_mode: str) -> dict[str, t.Any]:
    libs: dict[str, dict[str, t.Any]] = {}
    css: list[str] = []
    for cls in _resource_classes():
        # A spec with nothing but the shim has no libs or css to declare.
        if not _declares_resources(cls):
            continue
        try:
            spec = _build_spec(cls, resolved_mode)
        except Exception:
            continue
        if spec is None:
            continue
        for lib in spec.get('libs', []):
            libs.setdefault(lib['name'], lib)
        for url in spec.get('css', []):
            if url not in css:
                css.append(url)
    if not libs and not css:
        return {}
    declared: dict[str, t.Any] = {}
    if libs:
        declared['libs'] = list(libs.values())
    if css:
        declared['css'] = css
    return declared
