import {display, undisplay} from "@bokehjs/core/dom"
import {sum} from "@bokehjs/core/util/arrayable"
import {delay, paint} from "@bokehjs/core/util/defer"
import {isArray, isBoolean, isFunction, isString, isNumber} from "@bokehjs/core/util/types"
import {ModelEvent} from "@bokehjs/core/bokeh_events"
import type {StyleSheetLike} from "@bokehjs/core/dom"
import {div} from "@bokehjs/core/dom"
import {Enum} from "@bokehjs/core/kinds"
import type * as p from "@bokehjs/core/properties"
import {Model} from "@bokehjs/model"
import type {LayoutDOM} from "@bokehjs/models/layouts/layout_dom"
import {ColumnDataSource} from "@bokehjs/models/sources/column_data_source"
import type {Attrs, Data} from "@bokehjs/core/types"
import {ColumnsStreamedEvent} from "@bokehjs/document/events"
import type {DocumentChangedEvent} from "@bokehjs/document/events"

import {debounce} from "debounce"

import {cell_formatter} from "./cell_formatters"
import {comm_settings} from "./comm_manager"
import {transform_cds_rows_to_records, transform_cds_to_records} from "./data"
import {HTMLBox, HTMLBoxView} from "./layout"
import {schedule_when, transformJsPlaceholders} from "./util"

import tabulator_css from "styles/models/tabulator.css"

export class TableEditEvent extends ModelEvent {
  constructor(readonly column: string, readonly row: number, readonly value?: unknown, readonly old?: unknown) {
    super()
  }

  protected override get event_values(): Attrs {
    return {model: this.origin, column: this.column, row: this.row, value: this.value, old: this.old}
  }

  static {
    this.prototype.event_name = "table-edit"
  }
}

export class CellClickEvent extends ModelEvent {
  constructor(readonly column: string, readonly row: number) {
    super()
  }

  protected override get event_values(): Attrs {
    return {model: this.origin, column: this.column, row: this.row}
  }

  static {
    this.prototype.event_name = "cell-click"
  }
}

export class SelectionEvent extends ModelEvent {
  constructor(readonly indices: number[], readonly selected: boolean, readonly flush: boolean = false) {
    super()
  }

  protected override get event_values(): Attrs {
    return {model: this.origin, indices: this.indices, selected: this.selected, flush: this.flush}
  }

  static {
    this.prototype.event_name = "selection-change"
  }
}

declare const Tabulator: any

function find_group(key: any, value: string, records: any[]): any {
  for (const record of records) {
    if (record[key] == value) {
      return record
    }
  }
  return null
}

function summarize(grouped: any[], columns: any[], aggregators: any[], depth: number = 0): any {
  const summary: any = {}
  if (grouped.length == 0) {
    return summary
  }
  // depth level 0 is the root, finish here
  let aggs = ""
  if (depth > 0) {
    aggs = aggregators[depth-1]
  }

  for (const group of grouped) {
    const subsummary = summarize(group._children, columns, aggregators, depth+1)
    for (const col in subsummary) {
      if (isArray(subsummary[col])) {
        group[col] = sum(subsummary[col] as number[]) / subsummary[col].length
      } else {
        group[col] = subsummary[col]
      }
    }

    for (const column of columns.slice(1)) {
      // if no aggregation method provided for an index level,
      // or a specific column of an index level, do not aggregate data
      let agg: string = ""
      if (typeof aggs === "string") {
        agg = aggs
      } else if (column.field in aggs) {
        agg = aggs[column.field]
      }
      const val = group[column.field]
      if (column.field in summary) {
        const old_val = summary[column.field]
        if (agg === "min") {
          summary[column.field] = (val < old_val) ? val : old_val
        } else if (agg === "max") {
          summary[column.field] = (val > old_val) ? val : old_val
        } else if (agg === "sum") {
          summary[column.field] = val + old_val
        } else if (agg === "mean") {
          if (isArray(summary[column.field])) {
            summary[column.field].push(val)
          } else {
            summary[column.field] = [old_val, val]
          }
        }
      } else if (agg) {
        summary[column.field] = val
      }
    }
  }
  return summary
}

function group_data(records: any[], columns: any[], indexes: string[], aggregators: any): any[] {
  const grouped = []
  const index_field = columns[0].field
  for (const record of records) {
    const value = record[indexes[0]]
    let group = find_group(index_field, value, grouped)
    if (group == null) {
      group = {_children: []}
      group[index_field] = value
      grouped.push(group)
    }
    let subgroup = group
    for (const index of indexes.slice(1)) {
      subgroup = find_group(index_field, record[index], subgroup._children)
      if (subgroup == null) {
        subgroup = {_children: []}
        subgroup[index_field] = record[index]
        group._children.push(subgroup)
      }
      for (const column of columns.slice(1)) {
        subgroup[column.field] = record[column]
      }
      group = subgroup
    }
    for (const column of columns.slice(1)) {
      subgroup[column.field] = record[column.field]
    }
  }
  const aggs = []
  for (const index of indexes) {
    if (index in aggregators) {
      if (aggregators[index] instanceof Map) {
        // when some column names are numeric, need to convert that from a Map to an Object
        aggs.push(Object.fromEntries(aggregators[index]))
      } else {
        aggs.push(aggregators[index])
      }
    } else {
      aggs.push("")
    }
  }
  summarize(grouped, columns, aggs)
  return grouped
}

const timestampSorter = function(a: any, b: any, _aRow: any, _bRow: any, _column: any, _dir: any, _params: any) {
  // Bokeh/Panel serializes datetime objects as UNIX timestamps (in milliseconds).

  //a, b - the two values being compared
  //aRow, bRow - the row components for the values being compared (useful if you need to access additional fields in the row data for the sort)
  //column - the column component for the column being sorted
  //dir - the direction of the sort ("asc" or "desc")
  //sorterParams - sorterParams object from column definition array

  // Added an _ in front of some parameters as they're unused and the Typescript compiler was complaining about it.

  // const alignEmptyValues = params.alignEmptyValues
  let emptyAlign: any
  emptyAlign = 0

  const opts = {zone: new (window as any).luxon.IANAZone("UTC")}

  if (Number.isNaN(a)) {
    a = (window as any).luxon.DateTime.fromISO("invalid")
  } else {
    a = (window as any).luxon.DateTime.fromMillis(a, opts)
  }
  if (Number.isNaN(b)) {
    b = (window as any).luxon.DateTime.fromISO("invalid")
  } else {
    b = (window as any).luxon.DateTime.fromMillis(b, opts)
  }

  if (!a.isValid) {
    emptyAlign = !b.isValid ? 0 : -1
  } else if (!b.isValid) {
    emptyAlign =  1
  } else {
    //compare valid values
    return a - b
  }

  // Invalid (e.g. NaN) always at the bottom
  emptyAlign *= -1

  return emptyAlign
}

const dateEditor = function(cell: any, onRendered: any, success: any, cancel: any) {
  //cell - the cell component for the editable cell
  //onRendered - function to call when the editor has been rendered
  //success - function to call to pass the successfully updated value to Tabulator
  //cancel - function to call to abort the edit and return to a normal cell

  //create and style input
  const rawValue = cell.getValue()
  const opts = {zone: new (window as any).luxon.IANAZone("UTC")}
  let cellValue: any
  if (rawValue === "NaN" || rawValue === null) {
    cellValue = null
  } else {
    cellValue = (window as any).luxon.DateTime.fromMillis(rawValue, opts).toFormat("yyyy-MM-dd")
  }
  const input = document.createElement("input")

  input.setAttribute("type", "date")

  input.style.padding = "4px"
  input.style.width = "100%"
  input.style.boxSizing = "border-box"

  input.value = cellValue

  onRendered(() => {
    input.focus()
    input.style.height = "100%"
  })

  function onChange() {
    const new_val = (window as any).luxon.DateTime.fromFormat(input.value, "yyyy-MM-dd", opts).toMillis()
    if (new_val != cellValue) {
      success(new_val)
    } else {
      cancel()
    }
  }

  //submit new value on blur or change
  input.addEventListener("blur", onChange)

  //submit new value on enter
  input.addEventListener("keydown", (e) => {
    if (e.key == "Enter") {
      setTimeout(onChange, 100)
    }

    if (e.key == "Escape") {
      setTimeout(cancel, 100)
    }
  })

  return input
}

const datetimeEditor = function(cell: any, onRendered: any, success: any, cancel: any) {
  //cell - the cell component for the editable cell
  //onRendered - function to call when the editor has been rendered
  //success - function to call to pass the successfully updated value to Tabulator
  //cancel - function to call to abort the edit and return to a normal cell

  //create and style input
  const rawValue = cell.getValue()
  const opts = {zone: new (window as any).luxon.IANAZone("UTC")}
  let cellValue: any
  if (rawValue === "NaN" || rawValue === null) {
    cellValue = null
  } else {
    cellValue = (window as any).luxon.DateTime.fromMillis(rawValue, opts).toFormat("yyyy-MM-dd'T'T")
  }
  const input = document.createElement("input")

  input.setAttribute("type", "datetime-local")

  input.style.padding = "4px"
  input.style.width = "100%"
  input.style.boxSizing = "border-box"

  input.value = cellValue

  onRendered(() => {
    input.focus()
    input.style.height = "100%"
  })

  function onChange() {
    const new_val = (window as any).luxon.DateTime.fromFormat(input.value, "yyyy-MM-dd'T'T", opts).toMillis()
    if (new_val != cellValue) {
      success(new_val)
    } else {
      cancel()
    }
  }

  //submit new value on blur or change
  input.addEventListener("blur", onChange)

  //submit new value on enter
  input.addEventListener("keydown", (e) => {
    if (e.key == "Enter") {
      setTimeout(onChange, 100)
    }

    if (e.key == "Escape") {
      setTimeout(cancel, 100)
    }
  })

  return input
}

function is_spec(obj: any): boolean {
  return !(obj instanceof Model)
}

// Maps Bokeh CellEditor specs onto native Tabulator editors
function apply_editor_spec(tab_column: any, editor: any): void {
  switch (editor.type) {
    case "StringEditor":
      if (editor.completions.length > 0) {
        tab_column.editor = "list"
        tab_column.editorParams = {values: editor.completions, autocomplete: true, listOnEmpty: true}
      } else {
        tab_column.editor = "input"
      }
      break
    case "TextEditor":
      tab_column.editor = "textarea"
      break
    case "IntEditor":
    case "NumberEditor":
      tab_column.editor = "number"
      tab_column.editorParams = {step: editor.step}
      tab_column.validator = editor.type === "IntEditor" ? "integer" : "numeric"
      break
    case "CheckboxEditor":
      tab_column.editor = "tickCross"
      break
    case "DateEditor":
      tab_column.editor = dateEditor
      break
    case "SelectEditor":
      tab_column.editor = "list"
      tab_column.editorParams = {values: editor.options}
      break
    default:
      tab_column.editor = "input"
  }
}

const nestedEditor = function(cell: any, editorParams: any) {
  //cell - the cell component for the editable cell

  const row = cell.getRow().getData()
  let values = editorParams.options
  for (const i of editorParams.lookup_order) {
    values = row[i] in values ? values[row[i]] : []
    if (Array.isArray(values)) {
      break
    }
  }
  return values ? values : []
}

function find_column(group: any, field: string): any {
  if (group.columns != null) {
    for (const col of group.columns) {
      const found = find_column(col, field)
      if (found) {
        return found
      }
    }
  } else {
    return group.field === field ? group : null
  }
}

function clone_column(group: any): any {
  if (group.columns == null) {
    return {...group}
  }
  const group_columns = []
  for (const col of group.columns) {
    group_columns.push(clone_column(col))
  }
  return {...group, columns: group_columns}
}

const set_cache = new WeakMap<readonly number[], Set<number>>()

/** Tabulator queries membership once per row, so index arrays are looked up as sets. */
function as_set(indices: readonly number[]): Set<number> {
  let indices_set = set_cache.get(indices)
  if (indices_set === undefined) {
    indices_set = new Set(indices)
    set_cache.set(indices, indices_set)
  }
  return indices_set
}

/** Dicts with numeric keys deserialize as Maps, empty ones as plain objects. */
function lookup(mapping: any, key: any): any | null {
  if (mapping == null) {
    return null
  }
  return mapping instanceof Map ? (mapping.get(key) ?? null) : (mapping[key] ?? null)
}

function stream_length(data: Data): number | null {
  const columns: any[] = data instanceof Map ? [...data.values()] : Object.values(data)
  for (const column of columns) {
    return column.shape != null ? column.shape[0] : column.length
  }
  return null
}

/** Ignore Tabulator redraw after `after_resize` when `this.el` client size changes by at most this many pixels per axis. */
const EL_CLIENT_RESIZE_EPSILON_PX = 3

/**
 * Upper bound on waiting for `root.ready`. A view removed before its pending work
 * settles, e.g. a figure replaced before its scheduled paint, leaves the root's
 * ready chain pending forever, which would otherwise block every later redraw.
 */
const ROOT_READY_TIMEOUT_MS = 250
const RESIZE_BLOCKED_FRAMES = 10

export class DataTabulatorView extends HTMLBoxView {
  declare model: DataTabulator

  tabulator: any
  columns: Map<string, any> = new Map()
  container: HTMLDivElement | null = null
  _tabulator_cell_updating: boolean=false
  _pending_old_values: Map<string, any> = new Map()
  _updating_page: boolean = false
  _updating_expanded: boolean = false
  _updating_sort: boolean = false
  _updating_page_size: boolean = false
  _selection_updating: boolean = false
  _selection_pending: boolean = true
  _last_selected_row: any = null
  _initializing: boolean = true
  _lastVerticalScrollbarTopPosition: number = 0
  _lastHorizontalScrollbarLeftPosition: number = 0
  /** Bumped when `cell_styles` changes; cells styled with an older version are restyled when visible. */
  _styles_version: number = 0
  _styled_cells: WeakMap<HTMLElement, {version: number, props: string[]}> = new WeakMap()
  _building: boolean = false
  _pending_data: boolean = false
  /** A data update in flight; its `renderComplete` must not run `postUpdate` a second time. */
  _updating_data: boolean = false
  _redrawing: boolean = false
  _resized_columns: Map<string, number> = new Map()
  /** Coalesced resize redraw; waits for `this.root.ready` (Bokeh view async chain) before redrawing. */
  _resize_pending: boolean = false
  _resize_flush: Promise<void> | null = null
  _restore_scroll: boolean | "horizontal" | "vertical" = false
  _updating_scroll: boolean = false
  _pending_scroll_restores: number = 0
  _restored_scroll: {top: number, left: number} = {top: NaN, left: NaN}
  _is_scrolling: boolean = false
  _automatic_page_size: boolean = false
  _last_after_resize_el_width: number | null = null
  _last_after_resize_el_height: number | null = null
  _fonts_loaded: (() => void) | null = null

  override connect_signals(): void {
    super.connect_signals()
    const {
      configuration, layout, columns, groupby, visible, download,
      children, expanded, cell_styles, hidden_columns, page_size,
      page, max_page, frozen_rows, movable_columns, sorters, theme_classes,
    } = this.model.properties

    this.on_change([configuration, layout, groupby, movable_columns], debounce(() => {
      this.invalidate_render()
    }, 20, false))

    this.on_change(columns, () => {
      this.tabulator.setColumns(this.getColumns())
      this.setHidden()
    })

    this.on_change(download, () => {
      const ftype = this.model.filename.endsWith(".json") ? "json" : "csv"
      this.tabulator.download(ftype, this.model.filename)
    })

    this.on_change(children, () => this.renderChildren())

    this.on_change(expanded, () => {
      // A view whose render() has not run, or which has been torn down, has no Tabulator
      // instance. It can still be subscribed to the model, and throwing here aborts the whole
      // emit chain, so a sibling view that *is* rendered never gets to draw the row content and
      // the expand click appears to do nothing. Every other handler in this file guards this way.
      if (this.tabulator == null) {
        return
      }
      const expanded = as_set(this.model.expanded)
      // The first cell is the cell of the frozen _index column, the second
      // holds the expand icon, which must follow changes made from Python.
      for (const row of this.tabulator.rowManager.getRows()) {
        if (row.cells.length > 1) {
          row.cells[0].layoutElement()
          row.cells[1].element.innerText = expanded.has(row.data._index) ? "▼" : "►"
        }
      }
      // If content is embedded, views may not have been
      // rendered so if expanded is updated server side
      // we have to trigger a render
      if (this.model.embed_content && !this._updating_expanded) {
        this.renderChildren()
      }
    })

    this.on_change(cell_styles, () => {
      this._styles_version += 1
      this.setStyles()
    })
    this.on_change(hidden_columns, () => {
      this.setHidden()
      this.tabulator.columnManager.redraw(false)
    })
    this.on_change(page_size, () => this.setPageSize())
    this.on_change(page, () => {
      if (!this._updating_page) {
        this.setPage()
      }
    })
    this.on_change(visible, () => this.setVisibility())
    this.on_change(max_page, () => this.setMaxPage())
    this.on_change(frozen_rows, () => this.setFrozen())
    this.on_change(sorters, () => this.setSorters())
    this.on_change(theme_classes, () => this.setCSSClasses(this.tabulator.element))

    this.on_change(this.model.source.properties.data, () => {
      if (this.tabulator == null) {
        return
      }
      this._restore_scroll = "horizontal"
      this._selection_updating = true
      // The scroll event of a scroll just before may not have been handled yet.
      this.record_scroll()
      this._updating_scroll = true
      this._updating_data = true
      void this.setData().finally(() => {
        this._updating_data = false
      }).then(() => {
        this._selection_updating = false
        this.refitColumns()
        this.postUpdate()
        this.restore_scroll()
      })
    })
    // The streaming signal carries no payload; the document event also tells how
    // many rows were streamed and the rollover, which decide whether rows can be appended.
    const doc = this.model.document
    if (doc != null) {
      doc.on_change(this._on_document_change)
    } else {
      this.connect(this.model.source.streaming, () => this.addData(null, null))
    }
    this.connect(this.model.source.patching, (indices: unknown) => this.updateOrAddData(indices))
    this.connect(this.model.source.selected.change, () => this.setSelection())
    this.connect(this.model.source.selected.properties.indices.change, () => this.setSelection())
  }

  override disconnect_signals(): void {
    this.model.document?.remove_on_change(this._on_document_change)
    super.disconnect_signals()
  }

  private _on_document_change = (event: DocumentChangedEvent): void => {
    if (event instanceof ColumnsStreamedEvent && event.model === this.model.source && event.attr === "data") {
      this.addData(event.data, event.rollover ?? null)
    }
  }

  get groupBy(): boolean | ((data: any) => string) {
    const groupby = (data: any) => {
      const groups = []
      for (const g of this.model.groupby) {
        const group = `${g}: ${data[g]}`
        groups.push(group)
      }
      return groups.join(", ")
    }
    return (this.model.groupby.length > 0) ? groupby : false
  }

  get sorters(): any[] {
    const sorters = []
    if (this.model.sorters.length > 0) {
      sorters.push({column: "_index", dir: "asc"})
    }
    // Copy, the model array must not be reversed in place.
    for (const sort of [...this.model.sorters].reverse()) {
      sorters.push(sort.column === undefined ? {...sort, column: sort.field} : sort)
    }
    return sorters
  }

  override invalidate_render(): void {
    this.tabulator?.destroy()
    this.tabulator = null
    this._resized_columns.clear()
    this.rerender_()
  }

  refitColumns(field?: string): void {
    if (this._building || this.tabulator == null || !this.model.layout.startsWith("fit_data")) {
      return
    }
    if (field != null && this.model.layout !== "fit_data_stretch") {
      // Measuring a single column costs a fraction of re-measuring them all.
      const column = this.tabulator.getColumn(field)
      if (column != null && !this._resized_columns.has(field) && column.getDefinition().width == null) {
        column.setWidth(true)
      }
      return
    }
    this.tabulator.columnManager.layoutRefresh(true)
    // The refit discards the widths of columns the user has dragged.
    for (const [name, width] of this._resized_columns) {
      this.tabulator.getColumn(name)?.setWidth(width)
    }
  }

  redraw(columns: boolean = true, rows: boolean = true): void {
    if (this._building || this.tabulator == null || this._redrawing) {
      return
    }
    this._redrawing = true
    if (columns && (this.tabulator.columnManager.element != null)) {
      this.tabulator.columnManager.redraw(true)
    }
    if (rows && (this.tabulator.rowManager.renderer != null)) {
      this.tabulator.rowManager.redraw(true)
      this.setStyles()
    }
    this._redrawing = false
    this._restore_scroll = true
  }

  get is_drawing(): boolean {
    return this._building || this._redrawing || !this.has_finished()
  }

  override after_layout(): void {
    super.after_layout()
    if (this.tabulator != null && this._initializing && !this.is_drawing) {
      this._initializing = false
      if (this._selection_pending) {
        this.setSelection()
      }
      this._request_resize_redraw()
    }
  }

  override after_resize(): void {
    super.after_resize()
    if (this._is_scrolling || this._initializing || this.is_drawing) {
      return
    }
    const w = this.el.clientWidth
    const h = this.el.clientHeight
    if (
      this._last_after_resize_el_width !== null &&
      this._last_after_resize_el_height !== null &&
      Math.abs(w - this._last_after_resize_el_width) <= EL_CLIENT_RESIZE_EPSILON_PX &&
      Math.abs(h - this._last_after_resize_el_height) <= EL_CLIENT_RESIZE_EPSILON_PX
    ) {
      return
    }
    this._last_after_resize_el_width = w
    this._last_after_resize_el_height = h
    this._request_resize_redraw()
  }

  /**
   * Defer Tabulator redraw until the Bokeh root view’s `ready` promise settles — it chains async
   * work from connected signals (similar in spirit to waiting out `has_finished` / layout churn)
   * without polling `root.is_idle`.
   */
  private _request_resize_redraw(): void {
    this._resize_pending = true
    if (this._resize_flush !== null) {
      return
    }
    this._resize_flush = this._flush_resize_when_root_ready()
    void this._resize_flush.finally(() => {
      this._resize_flush = null
      if (this._resize_pending) {
        this._request_resize_redraw()
      }
    })
  }

  private async _flush_resize_when_root_ready(): Promise<void> {
    let blocked = 0
    while (true) {
      if (!this._resize_pending) {
        return
      }
      await Promise.race([
        this.root.ready,
        new Promise((resolve) => setTimeout(resolve, ROOT_READY_TIMEOUT_MS)),
      ])
      // `remove()` can clear `_resize_pending` while awaiting `root.ready`.
      /* eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- cleared asynchronously in `remove()` */
      if (!this._resize_pending) {
        continue
      }
      if (
        this._is_scrolling ||
        this._initializing ||
        this.container === null ||
        this.is_drawing ||
        this._has_active_editor() ||
        !this.stylesheets_settled
      ) {
        // `root.ready` is usually already resolved, so a blocking condition that persists
        // would otherwise spin this loop; back off once it outlasts a few frames.
        await (blocked++ < RESIZE_BLOCKED_FRAMES ? paint() : delay(ROOT_READY_TIMEOUT_MS))
        continue
      }
      this._resize_pending = false
      this._resize_redraw()
      return
    }
  }

  _resize_redraw(): void {
    if (this._initializing || this.container === null || this._building || this._has_active_editor()) {
      return
    }
    const width = this.container.clientWidth
    const height = this.container.clientHeight
    if (!(width > 0 && height > 0)) {
      return
    }
    this.record_scroll()
    this._updating_scroll = true
    this.redraw(true, true)
    this._updating_scroll = false
    this._pending_scroll_restores += 1
    requestAnimationFrame(() => {
      this._initializing = false
      if (this._selection_pending) {
        this.setSelection()
      }
      this._pending_scroll_restores -= 1
      this.restore_scroll()
      this.recompute_page_size()
    })
  }

  private _has_active_editor(): boolean {
    if (this.container === null) {
      return false
    }
    // Tabulator marks the edited cell with `tabulator-editing` while an editor is active.
    // A header filter list is a popup outside the cell, which a redraw would close.
    // A popup left behind hidden must not hold the redraw back forever.
    const filter_lists = [...this.shadow_el.querySelectorAll(".tabulator-edit-list")]
    return (
      this.container.querySelector(".tabulator-editing") !== null ||
      filter_lists.some((el) => el instanceof HTMLElement && el.offsetParent !== null)
    )
  }

  override stylesheets(): StyleSheetLike[] {
    return [...super.stylesheets(), tabulator_css]
  }

  setCSSClasses(el: HTMLDivElement): void {
    el.className = "pnx-tabulator tabulator"
    for (const cls of this.model.theme_classes) {
      el.classList.add(cls)
    }
  }

  override remove(): void {
    this.unwatch_fonts()
    this._resize_pending = false
    this._last_after_resize_el_width = null
    this._last_after_resize_el_height = null
    this.tabulator?.destroy()
    super.remove()
  }

  override render(): void {
    this.tabulator?.destroy()
    super.render()
    this._last_after_resize_el_width = null
    this._last_after_resize_el_height = null
    this._initializing = true
    this._building = true
    const container = div({style: {display: "contents"}})
    const el = div({style: {width: "100%", height: "100%", visibility: "hidden"}})
    this.container = el
    this.setCSSClasses(el)
    container.appendChild(el)
    this.shadow_el.appendChild(container)

    const configuration = this.getConfiguration()
    this.tabulator = new Tabulator(el, configuration)
    this.watch_stylesheets()
    this.watch_fonts()
    this.init_callbacks()
  }

  /**
   * Column widths are measured from the rendered text, so a web font that
   * finishes loading after the table was built leaves them too narrow.
   */
  watch_fonts(): void {
    this.unwatch_fonts()
    this._fonts_loaded = () => this._request_resize_redraw()
    document.fonts.addEventListener("loadingdone", this._fonts_loaded)
  }

  unwatch_fonts(): void {
    if (this._fonts_loaded !== null) {
      document.fonts.removeEventListener("loadingdone", this._fonts_loaded)
      this._fonts_loaded = null
    }
  }

  override style_redraw(): void {
    if (this.tabulator == null) {
      return
    }
    if (!this._initializing && !this._building) {
      this.redraw()
    }
    this.setVisibility()
  }

  /**
   * The table stays hidden until it is built and its stylesheets have settled,
   * otherwise its unstyled, unmeasured layout flashes before the final one.
   */
  setVisibility(): void {
    if (this.tabulator == null) {
      return
    }
    const ready = !this._building && this.stylesheets_settled
    this.tabulator.element.style.visibility = this.model.visible && ready ? "visible" : "hidden"
  }

  tableInit(): void {
    this._building = true
    // Patch the ajax request and page data parsing methods
    const ajax = this.tabulator.modules.ajax
    ajax.sendRequest = (_url: any, params: any, _config: any) => {
      return this.requestPage(params.page, params.sort)
    }
    this.tabulator.modules.page._parseRemoteData = (): boolean => {
      return false
    }
  }

  init_callbacks(): void {
    // Initialization
    this.tabulator.on("tableBuilding", () => this.tableInit())
    this.tabulator.on("tableBuilt", () => this.tableBuilt())

    // Rendering callbacks
    this.tabulator.on("selectableRowsCheck", (row: any) => {
      const selectable = this.model.selectable_rows
      return (selectable == null) || as_set(selectable).has(row._row.data._index)
    })
    this.tabulator.on("tooltips", (cell: any) => {
      return `${cell.getColumn().getField()}: ${cell.getValue()}`
    })
    // Rows scrolled back into view reuse their elements, so restyle them when `cell_styles` changed since.
    this.tabulator.on("scrollVertical", () => this.setStyles())

    // Sync state with model
    this.tabulator.on("rowSelectionChanged", (data: any, rows: any, selected: any, deselected: any) => {
      this.rowSelectionChanged(data, rows, selected, deselected)
    })
    this.tabulator.on("rowClick", (e: any, row: any) => this.rowClicked(e, row))
    this.tabulator.on("cellEdited", (cell: any) => this.cellEdited(cell))
    this.tabulator.on("columnResized", (column: any) => this._resized_columns.set(column.getField(), column.getWidth()))
    this.tabulator.on("dataFiltering", (filters: any) => {
      this.record_scroll()
      this.model.filters = filters
    })
    this.tabulator.on("dataFiltered", (_: any, rows: any[]) => {
      if (this._building) {
        return
      }
      // Ensure that after filtering empty scroll renders
      if (rows.length === 0) {
        this.tabulator.rowManager.renderEmptyScroll()
      }
      if (this.model.pagination != null) {
        // Ensure that after filtering the page is updated
        this.updatePage(this.tabulator.getPage())
      }
    })
    this.tabulator.on("pageLoaded", (pageno: number) => {
      this.updatePage(pageno)
    })
    this.tabulator.on("renderComplete", () => {
      if (this._building || this._updating_data) {
        return
      }
      this.postUpdate()
    })
    this.tabulator.on("dataSorting", (sorters: any[]) => {
      const sorts = []
      for (const s of sorters) {
        if (s.field !== "_index") {
          sorts.push({field: s.field, dir: s.dir})
        }
      }
      if (this.model.pagination !== "remote") {
        this._updating_sort = true
        this.model.sorters = sorts.reverse()
        this._updating_sort = false
      }
    })
  }

  tableBuilt(): void {
    this.setSelection()
    this.renderChildren()
    this.setStyles()

    // Track scrolling position and active scroll
    const holder = this.shadow_el.querySelector(".tabulator-tableholder")
    let scroll_timeout: ReturnType<typeof setTimeout> | undefined
    if (holder) {
      holder.addEventListener("scroll", () => {
        this.record_scroll()
        this._is_scrolling = true
        clearTimeout(scroll_timeout)
        scroll_timeout = setTimeout(() => {
          this._is_scrolling = false
        }, 200)
      })
    }

    if (this.model.pagination) {
      this.setMaxPage()
      this.tabulator.setPage(this.model.page)
    }
    this._initializing = this._building = false
    this.setVisibility()
    if (this._pending_data) {
      this._updating_data = true
      void this.setData().finally(() => {
        this._updating_data = false
      }).then(() => this.postUpdate())
    }
    this._request_resize_redraw()
  }

  recompute_page_size(): void {
    if (!this.model.pagination || (this.model.page_size !== null && !this._automatic_page_size) || this._initializing || !this.tabulator) {
      return
    }
    const holder = this.shadow_el.querySelector(".tabulator-tableholder")
    const table = this.shadow_el.querySelector(".tabulator-table")
    if (
      this.model.page_size != null &&
      this.model.page >= this.model.max_page &&
      table != null &&
      table.children.length < this.model.page_size
    ) {
      // Partial page: holder has shrunk to fit it, so its height doesn't
      // reflect full-page capacity. See https://github.com/holoviz/panel/issues/8737
      return
    }
    this._automatic_page_size = true
    const responsive = this.model.sizing_mode && (this.model.sizing_mode.includes("height") || this.model.sizing_mode.includes("both"))
    if (table != null && holder != null) {
      const table_height = holder.clientHeight
      let height = 0
      let page_size = null
      const heights = []
      for (let i = 0; i<table.children.length; i++) {
        const row_height = table.children[i].clientHeight
        heights.push(row_height)
        height += row_height
        if (height > table_height) {
          page_size = i
          if (responsive) {
            page_size -= 1
          }
          break
        }
      }
      if (heights.length === 0) {
        return
      }
      if (height < table_height) {
        page_size = table.children.length
        const remaining = table_height - height
        page_size += Math.floor(remaining / Math.min(...heights))
        if (responsive) {
          page_size -= 1
        }
      }
      this._updating_page_size = true
      try {
        this.model.page_size = Math.max(page_size || 1, 1)
      } finally {
        this._updating_page_size = false
      }
    }
  }

  requestPage(page: number, sorters: any[]): Promise<void> {
    return new Promise((resolve: any, reject: any) => {
      try {
        if (page != null && sorters != null) {
          this._updating_sort = true
          const sorts = []
          for (const s of sorters) {
            if (s.field !== "_index") {
              sorts.push({field: s.field, dir: s.dir})
            }
          }
          this.model.sorters = sorts
          this._updating_sort = false
          this._updating_page = true
          try {
            this.model.page = page || 1
          } finally {
            this._updating_page = false
          }
        }
        resolve([])
      } catch (err) {
        reject(err)
      }
    })
  }

  getLayout(): string {
    const layout = this.model.layout
    switch (layout) {
      case "fit_data":
        return "fitData"
      case "fit_data_fill":
        return "fitDataFill"
      case "fit_data_stretch":
        return "fitDataStretch"
      case "fit_data_table":
        return "fitDataTable"
      case "fit_columns":
        return "fitColumns"
    }
  }

  getConfiguration(): any {
    // Only use selectable mode if explicitly requested otherwise manually handle selections
    // Tabulator only skips marking rows as selectable (class and hover styling) for exactly false
    const selectableRows = this.model.select_mode === "toggle" ? true : (this.model.select_mode === false ? false : NaN)
    const configuration = {
      ...transformJsPlaceholders(this.model.configuration),
      index: "_index",
      nestedFieldSeparator: false,
      movableColumns: this.model.movable_columns,
      selectableRows,
      columns: this.getColumns(),
      initialSort: this.sorters,
      layout: this.getLayout(),
      pagination: this.model.pagination != null,
      paginationMode: this.model.pagination,
      paginationSize: this.model.page_size || 20,
      paginationInitialPage: 1,
      popupContainer: this.model.container_popup && this.container,
      groupBy: this.groupBy,
      frozenRows: (row: any) => {
        return (this.model.frozen_rows.length > 0) ? as_set(this.model.frozen_rows).has(row._row.data._index) : false
      },
      rowFormatter: (row: any) => {
        this._style_row(row)
        this._render_row(row, false)
      },
    }
    if (this.model.max_height != null) {
      configuration.maxHeight = this.model.max_height
    }
    if (this.model.pagination === "remote") {
      configuration.ajaxURL = "http://panel.pyviz.org"
      configuration.sortMode = "remote"
    }
    const data = this.getData()
    return {
      ...configuration,
      data,
    }
  }

  get_child(idx: number): LayoutDOM | null {
    if (this.model.children instanceof Map) {
      return this.model.children.get(idx) || null
    }
    return null
  }

  override get child_models(): LayoutDOM[] {
    const children: LayoutDOM[] = []
    for (const idx of this.model.expanded) {
      const child = this.get_child(idx)
      if (child != null) {
        children.push(child)
      }
    }
    return children
  }

  get row_index(): Map<number, any> {
    const rows = this.tabulator.getRows()
    const lookup = new Map()
    for (const row of rows) {
      const index = row._row?.data._index
      if (index != null) {
        lookup.set(index, row)
      }
    }
    return lookup
  }

  renderChildren(): void {
    void new Promise(async () => {
      await this.build_child_views()
      const lookup = this.row_index
      const expanded = this.model.expanded
      for (const index of expanded) {
        const model = this.get_child(index)
        const row = lookup.get(index)
        const view = model == null ? null : this._child_views.get(model)
        if (view != null) {
          this._render_row(row, index === expanded[expanded.length-1])
        }
      }
    })
  }

  _render_row(row: any, resize: boolean = true): void {
    const index = row._row?.data._index
    if (!as_set(this.model.expanded).has(index)) {
      return
    }
    const model = this.get_child(index)
    const view = model == null ? null : this._child_views.get(model)
    if (view == null) {
      return
    }
    schedule_when(() => {
      const rowEl = row.getElement()
      const neg_margin = rowEl.style.paddingLeft ? `-${rowEl.style.paddingLeft}` : "0"
      const prev_child = rowEl.children[rowEl.children.length-1]
      let viewEl
      if (prev_child != null && prev_child.className == "row-content") {
        viewEl = prev_child
        if (viewEl.children.length && viewEl.children[0] === view.el) {
          return
        }
      } else {
        const bg = getComputedStyle(this.tabulator.element.children[1].children[0]).backgroundColor
        viewEl = div({class: "row-content", style: {background_color: bg, margin_left: neg_margin, max_width: "100%", overflow_x: "hidden"}})
        rowEl.appendChild(viewEl)
      }
      display(view.el)
      viewEl.appendChild(view.el)
      if (view.shadow_el.children.length === 0) {
        this.rerender_(view)
      }
      if (resize) {
        this._update_children()
        this.resize_table()
      }
    }, () => this.has_finished())
  }

  resize_table(): void {
    if (this.tabulator.rowManager.renderer != null) {
      try {
        this.tabulator.rowManager.adjustTableSize()
      } catch (e) {}
    }
    this.invalidate_layout()
  }

  _expand_render(cell: any): string {
    const index = cell._cell.row.data._index
    return as_set(this.model.expanded).has(index) ? "▼" : "►"
  }

  _update_expand(cell: any): void {
    const index = cell._cell.row.data._index
    const expanded = [...this.model.expanded]
    if (!expanded.includes(index)) {
      expanded.push(index)
    } else {
      const exp_index = expanded.indexOf(index)
      const removed = expanded.splice(exp_index, 1)[0]
      const model = this.get_child(removed)
      if (model != null) {
        const view = this._child_views.get(model)
        if (view !== undefined && view.el != null) {
          undisplay(view.el)
        }
      }
    }
    this._updating_expanded = true
    this.model.expanded = expanded
    this._updating_expanded = false
    if (!expanded.includes(index)) {
      return
    }
    let ready = true
    for (const idx of this.model.expanded) {
      if (this.get_child(idx) == null) {
        ready = false
        break
      }
    }
    if (ready) {
      this.renderChildren()
    }
  }

  getData(): any[] {
    const cds = this.model.source
    let data: any[]
    if (cds === null || (cds.columns().length === 0)) {
      data = []
    } else {
      data = transform_cds_to_records(cds, true)
    }
    if (this.model.configuration.dataTree) {
      data = group_data(data, this.model.columns, this.model.indexes, this.model.aggregators)
    }
    return data
  }

  getColumns(): any {
    this.columns = new Map()
    const config_columns: (any[] | undefined) = transformJsPlaceholders(this.model.configuration?.columns)
    const columns = []
    columns.push({field: "_index", frozen: true, visible: false})
    if (config_columns != null) {
      for (const column of config_columns) {
        const new_column = clone_column(column)
        if (column.formatter === "expand") {
          const expand = {
            hozAlign: "center",
            cellClick: (_: any, cell: any) => {
              this._update_expand(cell)
            },
            formatter: (cell: any) => {
              return this._expand_render(cell)
            },
            width: 40,
            frozen: true,
          }
          columns.push(expand)
        } else {
          if (new_column.formatter === "rowSelection") {
            new_column.cellClick = (_: any, cell: any) => {
              cell.getRow().toggleSelect()
            }
          }
          columns.push(new_column)
        }
      }
    }
    for (const column of this.model.columns) {
      let tab_column: any = null
      if (config_columns != null) {
        for (const col of columns) {
          tab_column = find_column(col, column.field)
          if (tab_column != null) {
            break
          }
        }
      }
      if (tab_column == null) {
        tab_column = {field: column.field}
      }
      this.columns.set(column.field, tab_column)
      if (tab_column.title == null) {
        tab_column.title = column.title
      }
      if (tab_column.headerTooltip === undefined) {
        tab_column.headerTooltip = true
      }
      if (tab_column.width == null && column.width != null && column.width != 0) {
        tab_column.width = column.width
      }
      if (tab_column.formatter == null && column.formatter != null) {
        tab_column.formatter = this._get_formatter(column.formatter)
      }
      if (tab_column.sorter == "timestamp") {
        tab_column.sorter = timestampSorter
      }
      if (tab_column.sorter === undefined) {
        tab_column.sorter = "string"
      }
      const editor: any = column.editor
      const has_editor = editor != null && (is_spec(editor) ? editor.type !== "CellEditor" : editor.default_view != null)
      if (tab_column.editor != null) {
        if (tab_column.editor === "date") {
          tab_column.editor = dateEditor
        } else if (tab_column.editor === "datetime") {
          tab_column.editor = datetimeEditor
        } else if (tab_column.editor === "nested") {
          tab_column.editorParams.valuesLookup = (cell: any) => {
            return nestedEditor(cell, tab_column.editorParams)
          }
          tab_column.editor = "list"
        }
      } else if (has_editor && !is_spec(editor)) {
        tab_column.editor = (cell: any, onRendered: any, success: any, cancel: any) => {
          this.renderEditor(column, cell, onRendered, success, cancel)
        }
      } else if (has_editor) {
        apply_editor_spec(tab_column, editor)
      }
      tab_column.visible = (tab_column.visible != false && !this.model.hidden_columns.includes(column.field))
      const originalEditable = tab_column.editable
      if (isFunction(originalEditable)) {
        tab_column.editable = (cell: any) => (this.model.editable && has_editor && originalEditable(cell))
      } else if (isBoolean(originalEditable)) {
        tab_column.editable = () => (this.model.editable && has_editor && originalEditable)
      } else {
        tab_column.editable = () => (this.model.editable && has_editor)
      }
      if (tab_column.headerFilter) {
        if (isBoolean(tab_column.headerFilter) && isString(tab_column.editor)) {
          tab_column.headerFilter = tab_column.editor
          tab_column.headerFilterParams = tab_column.editorParams
        }
      }
      for (const sort of this.model.sorters) {
        if (tab_column.field === sort.field) {
          tab_column.headerSortStartingDir = sort.dir
        }
      }
      tab_column.cellClick = (_: any, cell: any) => {
        const index = cell.getData()._index
        const event = new CellClickEvent(column.field, index)
        this.model.trigger_event(event)
      }
      if (config_columns == null) {
        columns.push(tab_column)
      }
    }
    for (const col in this.model.buttons) {
      const button_formatter = () => {
        return this.model.buttons[col]
      }
      const button_column = {
        formatter: button_formatter,
        hozAlign: "center",
        cellClick: (_: any, cell: any) => {
          const index = cell.getData()._index
          const event = new CellClickEvent(col, index)
          this.model.trigger_event(event)
        },
      }
      columns.push(button_column)
    }
    if (this.model.container_popup && (this.model.layout !== "fit_data_stretch")) {
      // We insert an empty last column to ensure select editor is rendered in correct position
      // see: https://github.com/holoviz/panel/issues/7295
      columns.push({width: 1, maxWidth: 1, minWidth: 1, resizable: false, cssClass: "empty", headerSort: false})
    }
    return columns
  }

  _get_formatter(formatter: any): any {
    if (!is_spec(formatter)) {
      // Custom Bokeh CellFormatter model compiled as an extension
      return (cell: any) => {
        const row = cell.getRow()
        const node = div()
        node.innerHTML = formatter.doFormat(row, cell, cell.getValue(), null, row.getData())
        return node.children[0]
      }
    } else if (formatter.type === "BooleanFormatter") {
      return "tickCross"
    }
    const format = cell_formatter(formatter)
    if (format == null) {
      return undefined
    }
    return (cell: any) => format(cell.getValue(), cell.getRow().getData())
  }

  renderEditor(column: any, cell: any, onRendered: any, success: any, cancel: any): any {
    const editor = column.editor
    const view = new editor.default_view({column, model: editor, parent: this, container: cell._cell.element})
    view.initialize()
    view.connect_signals()
    onRendered(() => {
      view.setValue(cell.getValue())
    })

    view.inputEl.addEventListener("input", () => {
      const value = view.serializeValue()
      const old_value = cell.getValue()
      const validation = view.validate()
      if (!validation.valid) {
        cancel(validation.msg)
      }
      if (old_value != null && typeof value != typeof old_value) {
        cancel("Mismatching type")
      } else {
        success(view.serializeValue())
      }
    })

    return view.inputEl
  }

  // Update table
  setData(): Promise<void> {
    if (this._initializing || this._building || !this.tabulator.initialized) {
      // The table keeps the data it was built with, so apply this once it is
      this._pending_data = true
      return Promise.resolve(undefined)
    }
    this._pending_data = false
    const data = this.getData()
    if (this.model.pagination != null) {
      return this.tabulator.rowManager.setData(data, true, false)
    } else {
      return this.tabulator.setData(data)
    }
  }

  /** Whether rows can be added or updated in place rather than rebuilding the whole table. */
  get can_update_in_place(): boolean {
    return (
      this.tabulator != null &&
      this.tabulator.initialized &&
      !this._initializing &&
      !this._building &&
      !this._pending_data &&
      !this.model.configuration.dataTree
    )
  }

  /**
   * Appends the streamed rows. Rolling over drops leading rows and shifts every
   * `_index`, so that case (and anything out of sync) rebuilds the table.
   */
  addData(streamed: Data | null, rollover: number | null): void {
    if (this.tabulator == null) {
      return
    }
    const rows = this.tabulator.rowManager.getRows()
    const last_row = rows[rows.length-1]
    const start = ((last_row?.data._index) || 0)
    const total = this.model.source.get_length() ?? 0
    const n_streamed = streamed == null ? null : stream_length(streamed)
    const append = (
      n_streamed != null &&
      this.can_update_in_place &&
      rows.length + n_streamed === total &&
      (rollover == null || total <= rollover)
    )
    this._updating_page = true
    let update: Promise<unknown>
    if (append) {
      this._updating_data = true
      try {
        this._append_rows(transform_cds_to_records(this.model.source, true, rows.length))
      } finally {
        this._updating_data = false
      }
      update = Promise.resolve()
    } else {
      update = this.setData()
    }
    void update.then(async () => {
      try {
        if (!this.model.follow) {
          return
        }
        if (this.model.pagination) {
          await this.tabulator.setPage(Math.max(1, Math.ceil(this.tabulator.rowManager.getDataCount() / (this.model.page_size || 20))))
        }
        // With pagination the previous last row is often on an earlier page than
        // the one now shown, and Tabulator rejects scrolling to a row not displayed.
        const row = last_row ? this.tabulator.rowManager.findRow(start) : false
        if (row && this.tabulator.rowManager.getDisplayRows().includes(row)) {
          await this.tabulator.scrollToRow(start, "top", false)
        }
      } finally {
        this._updating_page = false
      }
    })
  }

  /**
   * Tabulator's `addData` copies the active rows array and, with pagination,
   * refreshes the whole data pipeline once per added row, which makes appending
   * a batch slower than rebuilding the table. This appends rows the way
   * `RowManager.addRows` does but refreshes once.
   */
  _append_rows(records: any[]): void {
    const manager = this.tabulator.rowManager
    // With pagination Tabulator places new rows on the current page unless the
    // preceding row is given explicitly.
    let after = this.model.pagination == null ? undefined : manager.rows[manager.rows.length - 1]
    const {setActiveRows, refreshActiveData} = manager
    manager.setActiveRows = () => {}
    manager.refreshActiveData = () => {}
    try {
      for (const record of records) {
        const row = manager.addRow(record, false, after, true)
        manager.dispatch("row-added", row, record, false, after)
        if (after !== undefined) {
          after = row
        }
      }
    } finally {
      manager.setActiveRows = setActiveRows
      manager.refreshActiveData = refreshActiveData
    }
    manager.setActiveRows(manager.activeRows)
    manager.refreshActiveData(false, false, true)
    manager.regenerateRowPositions()
    if (manager.displayRowsCount) {
      manager._clearPlaceholder()
    }
  }

  postUpdate(): void {
    this.setSelection()
    this.setStyles()
    // Tabulator also redraws by itself, e.g. when resized, resetting the scroll.
    const restore = this._restore_scroll || "horizontal"
    this.restore_scroll(restore !== "vertical", restore !== "horizontal")
    this._restore_scroll = false
  }

  /** Updates the patched rows in place; patches touching most rows rebuild the table instead. */
  updateOrAddData(indices: unknown): void {
    // To avoid double updating the tabulator data
    if (this._tabulator_cell_updating || this.tabulator == null) {
      return
    }
    const rows = this.tabulator.rowManager.getRows().length
    if (
      this.can_update_in_place &&
      // Tabulator does not regroup rows whose data is updated in place.
      !this.tabulator.options.groupBy &&
      isArray(indices) &&
      indices.length > 0 &&
      indices.length * 2 < rows &&
      indices.every(isNumber)
    ) {
      const records = transform_cds_rows_to_records(this.model.source, indices, true)
      if (records.length === indices.length) {
        // Rows updated in place are not re-sorted or re-filtered, refreshing
        // the filter re-runs the filter and sort stages of the data pipeline.
        const refresh = this.tabulator.getSorters().length > 0 || this.tabulator.getFilters(true).length > 0
        this.tabulator.updateData(records).then(() => {
          if (refresh) {
            this.tabulator.refreshFilter()
          }
        }).catch(() => this.replaceData())
        return
      }
    }
    this.replaceData()
  }

  replaceData(): void {
    const inds = this.model.source.selected.indices
    this.record_scroll()
    this._updating_scroll = true

    // Temporarily set minHeight to avoid "scroll-to-top" issues caused
    // by Tabulator JS entirely destroying the table when .setData is called.
    // Inspired by https://github.com/olifolkerd/tabulator/issues/4155
    const prev_minheight = this.tabulator.element.style.minHeight
    this.tabulator.element.style.minHeight = `${this.tabulator.element.offsetHeight}px`

    const data = this.getData()
    this.tabulator.setData(data).then(() => {
      this.tabulator.element.style.minHeight = prev_minheight
    })
    this._updating_scroll = false
    // Restore indices since updating data may have reset checkbox column
    this.model.source.selected.indices = inds
    this.restore_scroll()
  }

  setFrozen(): void {
    for (const row of this.model.frozen_rows) {
      this.tabulator.getRow(row).freeze()
    }
  }

  updatePage(pageno: number): void {
    if (this.model.pagination === "local" && this.model.page !== pageno && !this._updating_page) {
      this._updating_page = true
      this.model.page = pageno
      this._updating_page = false
      this.setStyles()
    }
  }

  setGroupBy(): void {
    this.tabulator.setGroupBy(this.groupBy)
  }

  setSorters(): void {
    if (this._updating_sort) {
      return
    }
    this.tabulator.setSort(this.sorters)
  }

  /** Styles the rendered rows; rows rendered later are styled by the `rowFormatter`. */
  setStyles(): void {
    if (this.tabulator == null || this.tabulator.rowManager.renderer == null) {
      return
    }
    // Chained so frozen rows, which sit outside the scrolled rows, are included.
    for (const row of this.tabulator.rowManager.getVisibleRows(true, true)) {
      if (row.type === "row") {
        this._style_row(row.getComponent())
      }
    }
  }

  _style_row(row: any): void {
    const version = this._styles_version
    const index = row._row?.data._index
    const row_style = index == null ? null : lookup(this.model.cell_styles.data, index)
    for (const cell of row._row?.cells ?? []) {
      const element: HTMLElement | undefined = cell.element
      if (element == null) {
        continue
      }
      const styled = this._styled_cells.get(element)
      if (styled != null && styled.version === version) {
        continue
      }
      if (styled != null) {
        for (const prop of styled.props) {
          element.style.removeProperty(prop)
        }
        this._styled_cells.delete(element)
      }
      const style: any[] | null = lookup(row_style, cell.column.field)
      const props: string[] = []
      for (const s of style ?? []) {
        let prop, value
        if (isArray(s)) {
          [prop, value] = s
        } else if (!s.includes(":")) {
          continue
        } else {
          [prop, value] = s.split(":")
        }
        element.style.setProperty(prop, value.trimLeft())
        props.push(prop)
      }
      this._styled_cells.set(element, {version, props})
    }
  }

  setHidden(): void {
    for (const column of this.tabulator.getColumns()) {
      const col = column._column
      if ((col.field == "_index") || this.model.hidden_columns.includes(col.field)) {
        column.hide()
      } else {
        column.show()
      }
    }
  }

  setMaxPage(): void {
    this.tabulator.setMaxPage(this.model.max_page)
    if (this.tabulator.modules.page.pagesElement) {
      this.tabulator.modules.page._setPageButtons()
    }
  }

  setPage(): void {
    this.tabulator.setPage(Math.min(this.model.max_page, this.model.page))
    if (this.model.pagination === "local") {
      this.setStyles()
    }
  }

  setPageSize(): void {
    if (!this._updating_page_size) {
      this._automatic_page_size = false
    }
    this.tabulator.setPageSize(this.model.page_size)
    if (this.model.pagination === "local") {
      this.setStyles()
    }
  }

  setSelection(): void {
    if (this._selection_updating) {
      return
    }
    if (this.tabulator == null || this._initializing || !this.tabulator.initialized) {
      this._selection_pending = true
      return
    }
    this._selection_pending = false

    const indices = this.model.source.selected.indices
    const current_indices: any = this.tabulator.getSelectedData().map((row: any) => row._index)
    if (JSON.stringify(indices) == JSON.stringify(current_indices)) {
      return
    }
    this._selection_updating = true
    this.tabulator.deselectRow()
    this.tabulator.selectRow(indices)
    // Scroll once, to the last selected row that is displayed (e.g. on the current page).
    const displayed = new Set(this.tabulator.rowManager.getDisplayRows())
    for (let i = indices.length - 1; i >= 0; i--) {
      const row = this.tabulator.rowManager.findRow(indices[i])
      if (row && displayed.has(row)) {
        this.tabulator.scrollToRow(indices[i], "center", false).catch(() => {})
        break
      }
    }
    this._selection_updating = false
  }

  restore_scroll(horizontal: boolean=true, vertical: boolean=true): void {
    if (!(horizontal || vertical)) {
      return
    }
    this._pending_scroll_restores += 1
    const apply = (attempts: number) => {
      requestAnimationFrame(() => {
        const el = this.tabulator?.rowManager?.element
        if (el == null) {
          this._pending_scroll_restores -= 1
          return
        }
        // Read when applied, so a scroll the user made meanwhile is kept.
        const opts: ScrollToOptions = {behavior: "instant"}
        if (vertical) {
          opts.top = this._lastVerticalScrollbarTopPosition
        }
        if (horizontal) {
          opts.left = this._lastHorizontalScrollbarLeftPosition
        }
        this._updating_scroll = true
        el.scrollTo(opts)
        this._updating_scroll = false
        if (vertical) {
          this._restored_scroll.top = el.scrollTop
        }
        if (horizontal) {
          this._restored_scroll.left = el.scrollLeft
        }
        // Rows still rendering clamp the position; offsets are fractional when zoomed.
        const restored = (
          (opts.top == null || Math.abs(el.scrollTop - opts.top) < 1) &&
          (opts.left == null || Math.abs(el.scrollLeft - opts.left) < 1)
        )
        if (!restored && attempts > 0) {
          apply(attempts - 1)
          return
        }
        this._pending_scroll_restores -= 1
      })
    }
    apply(10)
  }

  // Update model

  record_scroll() {
    if (this._updating_scroll) {
      return
    }
    const {scrollTop, scrollLeft} = this.tabulator.rowManager.element
    // Scroll events arrive after _updating_scroll is cleared, so while restoring
    // ignore the reset to the start and the clamped position.
    const pending = this._pending_scroll_restores > 0
    const restored = this._restored_scroll
    if (!pending || (scrollTop !== 0 && scrollTop !== restored.top)) {
      this._lastVerticalScrollbarTopPosition = scrollTop
    }
    if (!pending || (scrollLeft !== 0 && scrollLeft !== restored.left)) {
      this._lastHorizontalScrollbarLeftPosition = scrollLeft
    }
  }

  rowClicked(e: any, row: any) {
    if (
      this._selection_updating ||
        this._initializing ||
        isString(this.model.select_mode) ||
        this.model.select_mode === false ||  // selection disabled
        this.model.configuration.dataTree || // dataTree does not support selection
        e.srcElement?.innerText === "►"      // expand button
    ) {
      return
    }
    let indices: number[] = []
    const selected = this.model.source.selected
    const index: number = row._row.data._index

    if (e.ctrlKey || e.metaKey) {
      indices = [...selected.indices]
    } else if (e.shiftKey && this._last_selected_row) {
      const rows = row._row.parent.getDisplayRows()
      const start_idx = rows.indexOf(this._last_selected_row)
      if (start_idx !== -1) {
        const end_idx = rows.indexOf(row._row)
        const reverse = start_idx > end_idx
        const [start, end] = reverse ? [end_idx+1, start_idx+1] : [start_idx, end_idx]
        indices = rows.slice(start, end).map((r: any) => r.data._index)
        if (reverse) { indices = indices.reverse() }
      }
    }
    const flush = !(e.ctrlKey || e.metaKey || e.shiftKey)
    const includes = indices.includes(index)
    const remote = this.model.pagination === "remote"

    // Toggle the index on or off (if remote we let Python do the toggling)
    if (!includes || remote) {
      indices.push(index)
    } else {
      indices.splice(indices.indexOf(index), 1)
    }
    // Remove the first selected indices when selectable is an int.
    if (isNumber(this.model.select_mode)) {
      while (indices.length > this.model.select_mode) {
        indices.shift()
      }
    }
    const filtered = this._filter_selected(indices)
    if (!remote) {
      this.tabulator.deselectRow()
      this.tabulator.selectRow(filtered)
    }
    this._last_selected_row = row._row
    this._selection_updating = true
    if (!remote) {
      selected.indices = filtered
    }
    this.model.trigger_event(new SelectionEvent(indices, !includes, flush))
    this._selection_updating = false
  }

  _filter_selected(indices: number[]): number[] {
    const selectable = this.model.selectable_rows
    if (selectable == null) {
      return [...indices]
    }
    const selectable_set = as_set(selectable)
    return indices.filter((ind) => selectable_set.has(ind))
  }

  rowSelectionChanged(data: any, _row: any, selected: any, deselected: any): void {
    if (
      this._selection_updating ||
        this._initializing ||
        isBoolean(this.model.select_mode) ||
        isNumber(this.model.select_mode) ||
        this.model.configuration.dataTree
    ) {
      return
    }
    if (this.model.pagination === "remote") {
      const selected_indices = selected.map((x: any) => x._row.data._index)
      const deselected_indices = deselected.map((x: any) => x._row.data._index)
      if (selected_indices.length > 0) {
        this._selection_updating = true
        this.model.trigger_event(new SelectionEvent(selected_indices, true, false))
      }
      if (deselected_indices.length > 0) {
        this._selection_updating = true
        this.model.trigger_event(new SelectionEvent(deselected_indices, false, false))
      }
    } else {
      const indices: number[] = data.map((row: any) => row._index)
      const filtered = this._filter_selected(indices)
      this._selection_updating = indices.length === filtered.length
      this.model.source.selected.indices = filtered
    }
    this._selection_updating = false
  }

  cellEdited(cell: any): void {
    const field = cell._cell.column.field
    const column_def = this.columns.get(field)
    const index = cell.getData()._index
    const value = cell._cell.value
    const key = `${field}:${index}`
    const column = this.model.source.get_column(field)
    const nullable = Array.isArray(column) || column instanceof Float64Array || column instanceof Float32Array
    if (nullable && (column_def.validator === "numeric" || column_def.validator === "integer") && value === "") {
      // setValue below re-triggers cellEdited recursively for the actual
      // (NaN) edit. By then cell._cell.oldValue has already been overwritten
      // with this now-discarded "" attempt, so the true pre-edit value is
      // stashed here and picked back up on that recursive call.
      this._pending_old_values.set(key, cell._cell.oldValue)
      cell.setValue(NaN, true)
      return
    }
    let old_value = cell._cell.oldValue
    if (this._pending_old_values.has(key)) {
      old_value = this._pending_old_values.get(key)
      this._pending_old_values.delete(key)
    }
    this.model.trigger_event(new TableEditEvent(field, index, value, old_value))
    this._tabulator_cell_updating = true
    comm_settings.debounce = false
    try {
      this.model.source.patch({[field]: [[index, value]]})
    } finally {
      comm_settings.debounce = true
      this._tabulator_cell_updating = false
    }
    this.refitColumns(field)
    this.tabulator.scrollToRow(index, "top", false)
  }
}

export const TableLayout = Enum("fit_data", "fit_data_fill", "fit_data_stretch", "fit_data_table", "fit_columns")

export namespace TabulatorColumn {
  export type Attrs = p.AttrsOf<Props>
  export type Props = Model.Props & {
    field: p.Property<string>
    title: p.Property<string | null>
    width: p.Property<number>
    formatter: p.Property<any>
    editor: p.Property<any>
  }
}

export interface TabulatorColumn extends TabulatorColumn.Attrs {}

export class TabulatorColumn extends Model {
  declare properties: TabulatorColumn.Props

  constructor(attrs?: Partial<TabulatorColumn.Attrs>) {
    super(attrs)
  }

  static override __module__ = "panel.models.tabulator"

  static {
    this.define<TabulatorColumn.Props>(({Any, Float, Nullable, Str}) => ({
      field:     [ Str              ],
      title:     [ Nullable(Str), null ],
      width:     [ Float,          300 ],
      formatter: [ Nullable(Any), null ],
      editor:    [ Nullable(Any), null ],
    }))
  }
}

export namespace DataTabulator {
  export type Attrs = p.AttrsOf<Props>
  export type Props = HTMLBox.Props & {
    aggregators: p.Property<any>
    buttons: p.Property<any>
    children: p.Property<Map<number, LayoutDOM>>
    columns: p.Property<TabulatorColumn[]>
    configuration: p.Property<any>
    download: p.Property<boolean>
    editable: p.Property<boolean>
    embed_content: p.Property<boolean>
    expanded: p.Property<number[]>
    filename: p.Property<string>
    filters: p.Property<any[]>
    follow: p.Property<boolean>
    frozen_rows: p.Property<number[]>
    groupby: p.Property<string[]>
    hidden_columns: p.Property<string[]>
    indexes: p.Property<string[]>
    layout: p.Property<typeof TableLayout["__type__"]>
    max_page: p.Property<number>
    movable_columns: p.Property<boolean>
    page: p.Property<number>
    page_size: p.Property<number | null>
    pagination: p.Property<string | null>
    select_mode: p.Property<any>
    selectable_rows: p.Property<number[] | null>
    source: p.Property<ColumnDataSource>
    sorters: p.Property<any[]>
    cell_styles: p.Property<any>
    theme_classes: p.Property<string[]>
    container_popup: p.Property<boolean>
  }
}

export interface DataTabulator extends DataTabulator.Attrs { }

// The Bokeh .ts model corresponding to the Bokeh .py model
export class DataTabulator extends HTMLBox {
  declare properties: DataTabulator.Props

  constructor(attrs?: Partial<DataTabulator.Attrs>) {
    super(attrs)
  }

  static override __module__ = "panel.models.tabulator"

  static {
    this.prototype.default_view = DataTabulatorView

    this.define<DataTabulator.Props>(({Any, List, Bool, Nullable, Float, Ref, Str}) => ({
      aggregators:    [ Any,                     {} ],
      buttons:        [ Any,                     {} ],
      children:       [ Any,              new Map() ],
      configuration:  [ Any,                     {} ],
      columns:        [ List(Ref(TabulatorColumn)), [] ],
      download:       [ Bool,              false ],
      editable:       [ Bool,               true ],
      embed_content:  [ Bool,               false ],
      expanded:       [ List(Float),           [] ],
      filename:       [ Str,         "table.csv" ],
      filters:        [ List(Any),              [] ],
      follow:         [ Bool,               true ],
      frozen_rows:    [ List(Float),           [] ],
      groupby:        [ List(Str),           [] ],
      hidden_columns: [ List(Str),           [] ],
      indexes:        [ List(Str),           [] ],
      layout:         [ TableLayout,     "fit_data" ],
      max_page:       [ Float,                   0 ],
      movable_columns: [ Bool,               false ],
      pagination:     [ Nullable(Str),      null ],
      page:           [ Float,                   0 ],
      page_size:      [ Nullable(Float),       null ],
      select_mode:    [ Any,                   true ],
      selectable_rows: [ Nullable(List(Float)), null ],
      source:         [ Ref(ColumnDataSource)       ],
      sorters:        [ List(Any),              [] ],
      cell_styles:    [ Any,                     {} ],
      theme_classes:  [ List(Str),           [] ],
      container_popup: [ Bool, true ],
    }))
  }
}
